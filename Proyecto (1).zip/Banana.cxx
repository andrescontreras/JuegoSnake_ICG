#include "Banana.h"

Banana::
Banana(const std::string& fname, Mesh** omesh)
    :Object(fname,omesh)
{
    this->rotateZ(-1);
    this->rotateY(-11);
    this->m_RotationSpeed = 0.5;
    srand (time(NULL));
}

Banana::
~Banana()
{

}

bool Banana::
placeBanana(std::vector<std::tuple<int,int,int>> notPosible)
{
    int x  = 0;
    int z  = 0;
    int y = 0;
    int sig = 0;
    bool  encontrado = false;
    do
    {
       encontrado = false;
       sig= rand() % 2+1;
       x = rand() % 30+1;
       x = x-1;
       if(sig == 2)
         x = x*-1;
       sig= rand() % 2+1;
       z = rand() % 30+1;
       z = z-1;
       if(sig == 2)
         z = z*-1;
       y = -1;
       std::tuple<int,int,int> xyz (x,y,z);
       for(unsigned int i = 0; i <notPosible.size();i++ )
        {
            if(notPosible[i] == xyz)
            {
                encontrado = true;
                break;
            }
       }
    }while(encontrado);
    this->m_CoordX = x;
    this->m_CoordZ = z;
    this->m_CoordY = y;
    return true;

}

void Banana::
drawInOpenGLContext(GLenum mode)
{
    glPushMatrix();
    glTranslatef(this->m_CoordX,-0.5,this->m_CoordZ);
    this->rotateY(this->m_RotationSpeed);
    this->Object::drawInOpenGLContext(mode);
    glPopMatrix();
}
