// -------------------------------------------------------------------------
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// -------------------------------------------------------------------------

#include "Camera.h"
#include <cmath>
#include <GL/glu.h>
#include <iostream>
// -------------------------------------------------------------------------
Camera::
Camera( )
    : m_QuaternionReal( 1 ),
        m_QuaternionAxis( 0, 0, 0 )
{
  this->setFOV( 45 );
  this->setWindow( 1, 1 );
  this->setPlanes( 1e-2, 10000 );
  this->setAngles(0,0);
  this->setZoom(30);
  this->m_Position = Vector( );
  this->m_Focus = Vector( 0, 0, 0 );
  this->m_RightVector = Vector ( 1 );
  this->m_UpVector = Vector( 0, 1 );
  this->m_Rotations = Vector( );
  this->m_RefX = this->m_RefY = 0;
  //this->rotateY(2*_PI);
  this->loadCameraMatrix(0,0.5,0,5,0,0);
}

// -------------------------------------------------------------------------
Camera::
~Camera( )
{
}

// -------------------------------------------------------------------------
void Camera::
move( const Vector& dir )
{
  this->m_Position += dir;
}

void Camera::
placeCamera(int times, int direction, int nextDirection, int coordX,int coordY,int coordZ)
{
    if(times> 0)
    {
        float value = (_PI/10.0);
        switch(nextDirection)
        {
            case 1:
                if (direction != 2)
                {
                    if(direction == 3)
                    {
                        this->rotateY(-value);
                    }
                    else if (direction == 4)
                    {
                        this->rotateY(value);
                    }
                }
                break;
            case 2:
                if (direction != 1)
                {
                    if(direction == 3)
                    {
                        this->rotateY(value);
                    }
                    else if (direction == 4)
                    {
                        this->rotateY(-value);
                    }
                }
                break;
            case 3:
                if (direction != 4)
                {
                    if(direction == 1)
                    {
                        this->rotateY(value);
                    }
                    else if (direction == 2)
                    {
                        this->rotateY(-value);
                    }
                }
                break;
            case 4:
                if (direction != 3)
                {
                    if(direction == 1)
                    {
                        this->rotateY(-value);
                    }
                    else if (direction == 2)
                    {
                        this->rotateY(value);
                    }
                }
                break;
        }
        Vector axis = this->m_QuaternionAxis;
        float norm = axis.getNorm( );
        if( norm > 1e-5 )
        {
            float angle = std::acos( this->m_QuaternionReal ) * ( 2.0 / _PI_180 );
            glRotatef( angle, axis[ 0 ] / norm, axis[ 1 ] / norm, axis[ 2 ] / norm );
        } // end if
        glTranslatef((float)-coordX,(float)-coordY,(float)-coordZ);
    }
    else
    {
        Vector axis = this->m_QuaternionAxis;
        float norm = axis.getNorm( );
        if( norm > 1e-5 )
        {
            float angle = std::acos( this->m_QuaternionReal ) * ( 2.0 / _PI_180 );
            glRotatef( angle, axis[ 0 ] / norm, axis[ 1 ] / norm, axis[ 2 ] / norm );
        } // e
        glTranslatef((float)-coordX,(float)-coordY,(float)-coordZ);
    }
}

// -------------------------------------------------------------------------
void Camera::
rotateX(const float& angle)
{
  float s1 = std::cos( angle / 2.0 );
  float s2 = this->m_QuaternionReal;
  Vector a1( std::sin( angle / 2.0 ), 0, 0 );
  Vector a2 = this->m_QuaternionAxis;

  this->m_QuaternionReal = ( s1 * s2 ) - ( a1 / a2 );
  this->m_QuaternionAxis = ( a2 * s1 ) + ( a1 * s2 ) + ( a1 * a2 );
}

// -------------------------------------------------------------------------
void Camera::
rotateY(const float& angle)
{
   float s1 = std::cos( angle / 2.0 );
  float s2 = this->m_QuaternionReal;
  Vector a1( 0,std::sin( angle / 2.0 ), 0 );
  Vector a2 = this->m_QuaternionAxis;

  this->m_QuaternionReal = ( s1 * s2 ) - ( a1 / a2 );
  this->m_QuaternionAxis = ( a2 * s1 ) + ( a1 * s2 ) + ( a1 * a2 );
}
// -------------------------------------------------------------------------
void Camera::
setQuaternionAxis(Vector n_QuaternionAxis)
{
  this->m_QuaternionAxis = n_QuaternionAxis;
}

// -------------------------------------------------------------------------
void Camera::
setQuaternionReal(float n_QuaternionReal)
{
  this->m_QuaternionReal = n_QuaternionReal;
}

// -------------------------------------------------------------------------
Vector Camera::
getQuaternionAxis()
{
  return this->m_QuaternionAxis;
}

// -------------------------------------------------------------------------
float Camera::
getQuaternionReal()
{
  return this->m_QuaternionReal;
}

// -------------------------------------------------------------------------
void Camera::
rotateZ(const float& angle)
{
  float s1 = std::cos( angle / 2.0 );
  float s2 = this->m_QuaternionReal;
  Vector a1( 0, 0, std::sin( angle / 2.0 ));
  Vector a2 = this->m_QuaternionAxis;

  this->m_QuaternionReal = ( s1 * s2 ) - ( a1 / a2 );
  this->m_QuaternionAxis = ( a2 * s1 ) + ( a1 * s2 ) + ( a1 * a2 );
}

// -------------------------------------------------------------------------
void Camera::
forward( float d )
{
  this->m_Position += this->m_Focus * d;
}

// -------------------------------------------------------------------------
void Camera::
upward( float d )
{
  this->m_Position += this->m_UpVector * d;
}

// -------------------------------------------------------------------------
void Camera::
strafe( float d )
{
  this->m_Position += this->m_RightVector * d;
}

// -------------------------------------------------------------------------
void Camera::
getReference( int& dx, int& dy, int x, int y )
{
  dx = x - this->m_RefX;
  dy = y - this->m_RefY;
}

// -------------------------------------------------------------------------
void Camera::
setReference( int x, int y )
{
  this->m_RefX = x;
  this->m_RefY = y;
}

// -------------------------------------------------------------------------
void Camera::
setAngles( int x, int y )
{
  this->m_AngleX = x;
  this->m_AngleY = y;
}
// -------------------------------------------------------------------------
void Camera::
setZoom( int a)
{
  this->m_Zoom = a;
}

// -------------------------------------------------------------------------
void Camera::
increaseAngleX()
{
  m_AngleX +=3;
  if(m_AngleX >= 363)
  {
      m_AngleX = 3;
  }
}
// -------------------------------------------------------------------------
void Camera::
increaseAngleY()
{
  m_AngleY +=3;
  if(m_AngleY >= 183)
  {
      m_AngleY = 180;
  }
  if (m_AngleY== 90)
  {
    m_AngleY += 0.5;
  }
}

// -------------------------------------------------------------------------
void Camera::
decreaseAngleY()
{
  m_AngleY -=3;
  if(m_AngleY <= -3)
  {
      m_AngleY = 0;
  }
  if (m_AngleY == 90)
  {
    m_AngleY += 0.5;
  }
}

// -------------------------------------------------------------------------
void Camera::
decreaseAngleX()
{
  m_AngleX -=3;
  if(m_AngleX <= -3)
  {
      m_AngleX = 359;
  }
}


// -------------------------------------------------------------------------
void Camera::
increaseZoom()
{
  m_Zoom +=5;
}
// -------------------------------------------------------------------------
void Camera::
decreaseZoom()
{
  m_Zoom -=5;
  if(m_Zoom <= -5)
  {
      m_Zoom = 0;
  }
}


// -------------------------------------------------------------------------
void Camera::
loadCameraMatrix(float posX, float posY, float posZ, float targetX, float targetY, float targetZ)
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(posX, posY, posZ, targetX, targetY, targetZ, 0, 1, 0); // eye(x,y,z), focal(x,y,z), up(x,y,z)
}
// -------------------------------------------------------------------------
void Camera::
setFOV( float a )
{
  this->m_FOV = std::fmod( a, 360 );
}

// -------------------------------------------------------------------------
void Camera::
setPlanes( float n, float f )
{
  this->m_Near = n;
  this->m_Far = f;
}

// -------------------------------------------------------------------------
void Camera::
setWindow( int w, int h )
{
  this->m_WindowWidth = ( w > 0 )? w: 1;
  this->m_WindowHeight = ( h > 0 )? h: 1;
}

// -------------------------------------------------------------------------
void Camera::
loadProjectionMatrix( )
{
  glViewport( 0, 0, this->m_WindowWidth, this->m_WindowHeight );
  gluPerspective(
    this->m_FOV,
    float( this->m_WindowWidth ) / float( this->m_WindowHeight ),
    this->m_Near,
    this->m_Far
    );
}

// eof - Camera.cxx


