#ifndef __Skybox__h__
#define __Skybox__h__

#include <GL/glut.h>
#include "Tile.h"
class Skybox
{
public:
    Skybox();
    virtual ~Skybox();

    virtual void drawInOpenGLContext(GLenum mode);

protected:
    Tile*          m_Floor;
    Tile*          m_Boundary;
    Tile*          m_Sky;
};

#endif // __Skybox__h__

// eof - Skybox.h

