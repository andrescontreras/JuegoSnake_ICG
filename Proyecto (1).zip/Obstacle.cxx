#include "Obstacle.h"

Obstacle::
Obstacle(const std::string& obj_fname, const std::string& obj_fname2,const std::string& obs_fname )
{
    this->m_InternalObstacleMesh = new Mesh(obj_fname,"Textures/RattleSnakeTexture.bmp",0.780,0.956,0.376);
    this->m_ExternalObstacleMesh = new Mesh(obj_fname2,"Textures/PineTreeTexture.bmp",0.172,0.356,0.0078);
    std::ifstream in( obs_fname.c_str( ) );
  if( !in )
  {
    in.close( );
    throw std::runtime_error(
      std::string( "Error: Could not open \"" ) + obs_fname + "\""
      );
  } // end if
  std::istringstream buffer(
    std::string(
      ( std::istreambuf_iterator< char >( in ) ),
      std::istreambuf_iterator< char >( )
      )
    );
  in.close( );
  srand (time(NULL));
  // Read file
  buffer >> this;
}
Obstacle::
~Obstacle()
{
    if(this->m_ExternalObstacleMesh != nullptr)
        delete(this->m_ExternalObstacleMesh);
    if(this->m_InternalObstacleMesh != nullptr)
        delete(this->m_InternalObstacleMesh);
    this->m_ExternalObstacleMesh = this->m_InternalObstacleMesh = nullptr;
    for( Object* c: this->m_ExternalObstacles)
        delete c;
    for( Object* c: this->m_Obstacles )
        delete c;
}

void Obstacle::
changeVboSup()
{
    this->m_ExternalObstacleMesh->changeVboSup();
    this->m_InternalObstacleMesh->changeVboSup();
}

std::vector<Object*>  Obstacle::
getObstacles()
{
    return this->m_Obstacles;
}

std::vector<std::tuple<int,int,int>>  Obstacle::
getObstaclesCoordinates()
{
    std::vector<std::tuple<int,int,int>> aux;
    for(unsigned int i = 0; i < this->m_Obstacles.size();i++)
    {
        aux.push_back(std::tuple<int,int,int>(this->m_Obstacles[i]->getCoordX(),-1,this->m_Obstacles[i]->getCoordZ()));
    }
    return aux;
}

std::vector<std::tuple<int,int,int>>  Obstacle::
getExternalObstaclesCoordinates()
{
    std::vector<std::tuple<int,int,int>> aux;
    for(unsigned int i = 0; i < this->m_ExternalObstacles.size();i++)
    {
        aux.push_back(std::tuple<int,int,int>(this->m_ExternalObstacles[i]->getCoordX(),-1,this->m_ExternalObstacles[i]->getCoordZ()));
    }
    return aux;
}

void Obstacle::
addObstacle(int i, int j)
{
    Object* newObstacle = new Object("Param/snake.txt",&this->m_InternalObstacleMesh);
    newObstacle->setCoordX(i);
    newObstacle->setCoordZ(j);
    newObstacle->setCoordY(-1);
    newObstacle->rotateX(11);
    int sig= rand() % 26+1;
    newObstacle->rotateY(sig*0.25132741228);
    this->m_Obstacles.push_back(newObstacle);
}

void Obstacle::
addExternalObstacle(int i, int j)
{
    Object* newObstacle = new Object("Param/tree.txt",&this->m_ExternalObstacleMesh);
    newObstacle->setCoordX(i);
    newObstacle->setCoordZ(j);
    newObstacle->setCoordY(-1);
    int sig= rand() % 26+1;
    newObstacle->rotateY(sig*0.25132741228);
    this->m_ExternalObstacles.push_back(newObstacle);
}

void Obstacle::
drawInOpenGLContext(GLenum mode)
{
    glPushMatrix();
    for (unsigned int i = 0; i < this->m_Obstacles.size(); i++)
    {
        glPushMatrix();
        glTranslatef(this->m_Obstacles[i]->getCoordX(),this->m_Obstacles[i]->getCoordY(),this->m_Obstacles[i]->getCoordZ());
        this->m_Obstacles[i]->drawInOpenGLContext(mode);
        glPopMatrix();
    }
    glPopMatrix();
    glPushMatrix();
    for (unsigned int i = 0; i < this->m_ExternalObstacles.size(); i++)
    {
        glPushMatrix();
        glTranslatef(this->m_ExternalObstacles[i]->getCoordX(),this->m_ExternalObstacles[i]->getCoordY(),this->m_ExternalObstacles[i]->getCoordZ());
        this->m_ExternalObstacles[i]->drawInOpenGLContext(GL_TRIANGLES);
        glPopMatrix();
    }
    glPopMatrix();
}

// -------------------------------------------------------------------------

void Obstacle::
_strIn( std::istream& in )
{
  // Read data for this spatial object
  int i,  j;
  while( !in.eof( ) )
  {
      std::string line;
      in >> line;
      in >> i >> j;
      if(line == "ex" || line == "Ex" || line == "EX")
        this->addExternalObstacle(i,j);
      else if (line == "in" || line == "In" || line == "IN")
        this->addObstacle(i,j);
  }

}

// -------------------------------------------------------------------------
void Obstacle::
_strOut( std::ostream& out ) const
{
}
