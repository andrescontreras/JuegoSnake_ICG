#include "World.h"



World::
World(int level)
{
  this->m_BananaMesh = new Mesh("Objects/Banana.obj",0.937254,0.992156,0.164705);
  this->m_Banana     = new Banana("Param/banana.txt",&this->m_BananaMesh);
  this->m_Conga      = new Conga("Objects/MonitoSpider.obj");
  std::string lev = "Levels/Obstaculos"+std::to_string(level)+".txt";
  this->m_Obstacle   = new Obstacle("Objects/RattleSnake.obj","Objects/PineTree.obj",lev);
  this->m_Conga->addMonkey(0,0);
  this->m_Skybox = new Skybox();
  this->m_Camera     = new Camera();
  std::vector<Monkey*> monkeys = this->m_Conga->getMonkeys();
  std::vector<std::tuple<int,int,int>> notPosible = this->m_Obstacle->getObstaclesCoordinates();
  for(unsigned int i = 0; i <monkeys.size(); i++ )
  {
        std::tuple<int,int,int> coords(monkeys[i]->getCoordX(),monkeys[i]->getCoordY(),monkeys[i]->getCoordZ());
        notPosible.push_back(coords);
  }
  this->m_Banana->placeBanana(notPosible);
}

World::
~World()
{
    if(this->m_BananaMesh != nullptr)
        delete(this->m_BananaMesh);
    this->m_BananaMesh = nullptr;
    if(this->m_Banana != nullptr)
        delete(this->m_Banana);
    this->m_Banana = nullptr;
    if(this->m_Camera != nullptr)
        delete(this->m_Camera);
    this->m_Camera = nullptr;
    if(this->m_Conga != nullptr)
        delete(this->m_Conga);
    this->m_Conga = nullptr;
    if(this->m_Obstacle != nullptr)
        delete(this->m_Obstacle);
    this->m_Obstacle = nullptr;
    if(this->m_Skybox != nullptr)
        delete(this->m_Skybox);
    this->m_Skybox = nullptr;
}


int World::
getSizeofConga()
{
    return this->m_Conga->getSizeofConga();
}

void World::
placeCamera()
{
    Monkey* mon = this->m_Conga->getHead();
    if(mon->getTimes() == 0)
        this->m_Camera->placeCamera(mon->getTimes(),mon->getDirection(),mon->getNextDirection(),mon->getCoordX(),mon->getCoordY(),mon->getCoordZ());
    else
        this->m_Camera->placeCamera(mon->getTimes(),mon->getDirection(),mon->getNextDirection(),mon->getPrevCoordX(),mon->getPrevCoordY(),mon->getPrevCoordZ());

}

bool World::
moveMonkeys(int dir,int jump)
{
    bool encontrado = false;
    std::vector<Monkey*> monkeys = this->m_Conga->getMonkeys();
    std::tuple<int,int,int> xyz (monkeys[0]->getCoordX(),monkeys[0]->getCoordY(),monkeys[0]->getCoordZ());
    std::tuple<int,int,int> chg (monkeys[monkeys.size()-1]->getCoordX(),monkeys[monkeys.size()-1]->getCoordY(),monkeys[monkeys.size()-1]->getCoordZ());
    std::vector<std::tuple<int,int,int>> notPosible = this->m_Obstacle->getObstaclesCoordinates();
    monkeys.erase(monkeys.begin());
    for(unsigned int i = 0; i < notPosible.size() && !encontrado;i++)
    {
        if(notPosible[i] == xyz)
            encontrado = true;
    }
    for(unsigned int i = 0; i <monkeys.size() && !encontrado; i++ )
    {
        std::tuple<int,int,int> coords(monkeys[i]->getCoordX(),monkeys[i]->getCoordY(),monkeys[i]->getCoordZ());
        if(coords == xyz)
            encontrado = true;
        else
            notPosible.push_back(coords);
    }
    if(!encontrado)
    {
        if(std::get<0>(xyz) == 30 || std::get<0>(xyz) == -30 || std::get<2>(xyz) == 30 || std::get<2>(xyz) == -30)
        {
           this->m_Conga->teleportMonkeys(std::get<0>(xyz),std::get<2>(xyz));
        }
        this->m_Conga->moveMonkeys(dir,jump);
        std::tuple <int,int,int> banana(this->m_Banana->getCoordX(),this->m_Banana->getCoordY(),this->m_Banana->getCoordZ());
        if(xyz == banana )
        {
               notPosible.push_back(xyz);
               this->m_Banana->placeBanana(notPosible);
               this->m_Conga->addMonkey(std::get<0>(chg), std::get<2>(chg));
        }
    }
    else
    {
        return false;
    }
    return true;
}

void World::
changeVboSup()
{
    this->m_BananaMesh->changeVboSup();
    this->m_Conga->changeVboSup();
    this->m_Obstacle->changeVboSup();
}
void World::
getBananaCoords(int& coordX, int& coordY)
{
    coordX = this->m_Banana->getCoordX();
    coordY = this->m_Banana->getCoordZ();
}
void World::
drawInOpenGLContext(GLenum mode, bool fpc)
{
    glPushMatrix();
    this->m_Conga->drawInOpenGLContext(GL_QUADS,fpc);
    glPopMatrix();
    glPushMatrix();
    this->m_Banana->drawInOpenGLContext(GL_QUADS);
    glPopMatrix();
    glPushMatrix();
    this->m_Obstacle->drawInOpenGLContext(GL_QUADS);
    glPopMatrix();
    glPushMatrix();
    this->m_Skybox->drawInOpenGLContext(GL_TRIANGLES);
    glPopMatrix();
}
