#include "Monkey.h"

Monkey::
Monkey(const std::string& fname, Mesh** omesh)
    :Object(fname,omesh),
        m_Times(0)
{
    this->rotateX(11);
    this->rotateY(-11);
    this->m_CoordX = 0;
    this->m_CoordY = -1;
    this->m_CoordZ = 0;
    this->m_ScaleX = 0.01;
    this->m_ScaleY = 0.01;
    this->m_ScaleZ = 0.01;
    this->m_Animating = false;
}
Monkey::
~Monkey()
{
}


int Monkey::
getPrevCoordX()
{
    return this->m_PrevCoordX;
}

int Monkey::
getPrevCoordY()
{
    return this->m_PrevCoordY;
}

int Monkey::
getPrevCoordZ()
{
    return this->m_PrevCoordZ;
}

int Monkey::
getDirection()
{
    return this->m_Direction;
}
int Monkey::
getNextDirection()
{
    return this->m_NextDirection;
}

int Monkey::
getTimes()
{
    return this->m_Times;
}

void Monkey::
setTimes()
{
    this->m_Times = 5;
}
void Monkey::
setPrevCoordX(int coordX)
{
    this->m_PrevCoordX = coordX;
}
void Monkey::
setPrevCoordY(int coordY)
{
    this->m_PrevCoordY = coordY;
}
void Monkey::
setPrevCoordZ(int coordZ)
{
    this->m_PrevCoordZ = coordZ;
}
void Monkey::
setNextDirection(int dir)
{
    this->m_NextDirection = dir;
}


void Monkey::
drawInOpenGLContext( GLenum mode , bool fpc)
{
    if(this->m_Times> 0)
    {
        float value = (_PI/10.0);
        switch(this->m_NextDirection)
        {
            case 1:
                if (this->m_Direction != 2)
                {
                    if(this->m_Direction == 3)
                    {
                        this->rotateY(value);
                    }
                    else if (this->m_Direction == 4)
                    {
                        this->rotateY(-value);
                    }
                }
                break;
            case 2:
                if (this->m_Direction != 1)
                {
                    if(this->m_Direction == 3)
                    {
                        this->rotateY(-value);
                    }
                    else if (this->m_Direction == 4)
                    {
                        this->rotateY(value);
                    }
                }
                break;
            case 3:
                if (this->m_Direction != 4)
                {
                    if(this->m_Direction == 1)
                    {
                        this->rotateY(-value);
                    }
                    else if (this->m_Direction == 2)
                    {
                        this->rotateY(value);
                    }
                }
                break;
            case 4:
                if (this->m_Direction != 3)
                {
                    if(this->m_Direction == 1)
                    {
                        this->rotateY(value);
                    }
                    else if (this->m_Direction == 2)
                    {
                        this->rotateY(-value);
                    }
                }
                break;
        }
        this->m_Times--;
        glPushMatrix();
        glTranslatef((float)this->m_PrevCoordX,(float)this->m_PrevCoordY,(float)this->m_PrevCoordZ);
        if (!fpc)
            this->Object::drawInOpenGLContext(mode);
        glPopMatrix();
        if(this->m_Times == 0)
        {
           this->m_Direction = this->m_NextDirection;
        }

    }
    else
    {
        glPushMatrix();
        glTranslatef((float)this->m_CoordX,(float)this->m_CoordY,(float)this->m_CoordZ);
        if (!fpc)
            this->Object::drawInOpenGLContext(mode);
        glPopMatrix();
    }
}
