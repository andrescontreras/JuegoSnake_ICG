
#include "Tile.h"

Tile::
Tile(const std::string& fname)
    :m_VboId(0),                   // ID of VBO for vertex arrays
     m_IboId(0),                   // ID of VBO for index array
     m_TexId(0)
{
    glExtension& ext = glExtension::getInstance();
    bool vboSup = ext.isSupported("GL_ARB_vertex_buffer_object");
    this->m_VboSup = vboSup;
    if(vboSup)
    {
        // create vertex buffer objects, you need to delete them when program exits
        // Try to put both vertex coords array, vertex normal array and vertex color in the same buffer object.
        // glBufferData with NULL pointer reserves only memory space.
        // Copy actual data with multiple calls of glBufferSubData for vertex positions, normals, colors, etc.
        // target flag is GL_ARRAY_BUFFER, and usage flag is GL_STATIC_DRAW
        glGenBuffers(1, &this->m_VboId);
        glBindBuffer(GL_ARRAY_BUFFER, this->m_VboId);
        glBufferData(GL_ARRAY_BUFFER, sizeof(this->m_Vertices)+sizeof(this->m_Normals)+sizeof(this->m_Colors)+sizeof(this->m_TexCoords), 0, GL_STATIC_DRAW);
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(this->m_Vertices), this->m_Vertices);                                                    // copy vertices starting from 0 offest
        glBufferSubData(GL_ARRAY_BUFFER, sizeof(this->m_Vertices), sizeof(this->m_Normals), this->m_Normals);
        glBufferSubData(GL_ARRAY_BUFFER, sizeof(this->m_Vertices)+sizeof(this->m_Normals), sizeof(this->m_Colors), this->m_Colors);                         // copy colours after normals                                       // copy normals after vertices
        glBufferSubData(GL_ARRAY_BUFFER, sizeof(this->m_Vertices)+ sizeof(this->m_Normals)+sizeof(this->m_Colors), sizeof(this->m_TexCoords), this->m_TexCoords); // copy colours after normals
        glBindBuffer(GL_ARRAY_BUFFER, 0);

        glGenBuffers(1, &this->m_IboId);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, this->m_IboId);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(this->m_Indices), this->m_Indices, GL_STATIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    }

    // load an bitmap from disk
    Image::Bmp bmp;
    bmp.read(fname.c_str());
    int imageWidth = bmp.getWidth();
    int imageHeight = bmp.getHeight();

    // determine texture format based on # of bits per pixel
    GLint format, internalFormat;
    int bitCount = bmp.getBitCount();
    switch(bitCount)
    {
        case 8:
            format = GL_LUMINANCE;
            internalFormat = GL_LUMINANCE8;
            break;
        case 24:
            format = GL_RGB;
            internalFormat = GL_RGB8;
            break;
        case 32:
            format = GL_RGBA;
            internalFormat = GL_RGBA8;
            break;
        default:
            format = GL_RGBA;
            internalFormat = GL_RGBA8;
    }

    // copy the texture to OpenGL
    glGenTextures(1, &this->m_TexId);

    // set active texture and configure it
    glBindTexture(GL_TEXTURE_2D, this->m_TexId);

    // select modulate to mix texture with color for shading
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

    //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE); // automatic mipmap generation included in OpenGL v1.4

    // copy bitmap data to texture object
    glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, imageWidth, imageHeight, 0, format, GL_UNSIGNED_BYTE, bmp.getDataRGB());
    // unbind
    glBindTexture(GL_TEXTURE_2D, 0);
}

Tile::
~Tile()
{
    deleteVBO(this->m_VboId);
    deleteVBO(this->m_IboId);
    deleteVBO(this->m_TexId);
    this->m_IboId = this->m_VboId =this->m_TexId = 0;
}

void Tile::
deleteVBO(GLuint vboId)
{
    glDeleteBuffers(1, &vboId);
}

void Tile::
drawInOpenGLContext(GLenum mode)
{
    if(this->m_VboSup) // draw cube using VBO
    {
        // bind VBOs with IDs and set the buffer offsets of the bound VBOs
        // When buffer object is bound with its ID, all pointers in gl*Pointer()
        // are treated as offset instead of real pointer.
        glBindBuffer(GL_ARRAY_BUFFER, this->m_VboId);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, this->m_IboId);

        // enable vertex arrays
        glEnableClientState(GL_NORMAL_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        glEnableClientState(GL_VERTEX_ARRAY);

        // before draw, specify vertex and index arrays with their offsets
        glNormalPointer(GL_FLOAT, 0, (void*)sizeof(this->m_Vertices));
        glColorPointer(3, GL_FLOAT, 0, (void*)(sizeof(this->m_Vertices)+sizeof(this->m_Normals)));
        glTexCoordPointer(2, GL_FLOAT, 0, (void*)(sizeof(this->m_Vertices)+sizeof(this->m_Normals)+sizeof(this->m_Colors)));
        glVertexPointer(3, GL_FLOAT, 0, 0);

        glBindTexture(GL_TEXTURE_2D, this->m_TexId);
        glDrawElements(mode,            // primitive type
                       36,                      // # of indices
                       GL_UNSIGNED_INT,         // data type
                       (void*)0);               // ptr to indices

        glDisableClientState(GL_VERTEX_ARRAY);  // disable vertex arrays
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_NORMAL_ARRAY);

        // it is good idea to release VBOs with ID 0 after use.
        // Once bound with 0, all pointers in gl*Pointer() behave as real
        // pointer, so, normal vertex array operations are re-activated
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    }

    // draw a cube using vertex array method
    // notice that only difference between VBO and VA is binding buffers and offsets
    else
    {
        // enable vertex arrays
        glEnableClientState(GL_NORMAL_ARRAY);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        glEnableClientState(GL_VERTEX_ARRAY);

        // before draw, specify vertex arrays
        glNormalPointer(GL_FLOAT, 0, this->m_Normals);
        glTexCoordPointer(2, GL_FLOAT, 0, this->m_TexCoords);
        glVertexPointer(3, GL_FLOAT, 0, this->m_Vertices);

        glBindTexture(GL_TEXTURE_2D, this->m_TexId);
        glDrawElements(mode,            // primitive type
                       36,                      // # of indices
                       GL_UNSIGNED_INT,         // data type
                       (void*)this->m_Indices);         // ptr to indices

        glDisableClientState(GL_VERTEX_ARRAY);  // disable vertex arrays
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
        glDisableClientState(GL_NORMAL_ARRAY);
    }

}
