

// -------------------------------------------------------------------------
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// -------------------------------------------------------------------------
#ifndef __Monkey__h__
#define __Monkey__h__


#include "Object.h"
#include <GL/glut.h>

class Monkey: public Object
{
public:
    Monkey(const std::string& fname, Mesh** omesh);
    virtual ~Monkey();
    void setTimes();
    int  getDirection();
    int  getNextDirection();
    int  getTimes();
    int  getPrevCoordX();
    int  getPrevCoordY();
    int  getPrevCoordZ();
    void setPrevCoordX(int coordX);
    void setPrevCoordY(int coordY);
    void setPrevCoordZ(int coordZ);
    void setNextDirection(int dir);

    virtual void drawInOpenGLContext( GLenum mode , bool fpc);

protected:
    int           m_NextDirection;
    int           m_Times;
    int           m_Direction;
    int           m_PrevCoordX;
    int           m_PrevCoordY;
    int           m_PrevCoordZ;

};
#endif // __Monkey__h__

// eof - Monkey.h
