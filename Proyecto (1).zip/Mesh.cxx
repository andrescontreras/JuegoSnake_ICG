// -------------------------------------------------------------------------
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// -------------------------------------------------------------------------

#include "Mesh.h"

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
const GLfloat mat_specular[]   = { 0.1f, 0.1f, 0.1f, 0.1f };
const GLfloat high_shininess[] = { 50.0f };
// -------------------------------------------------------------------------
Mesh::
Mesh( )
{
  std::vector<float> a;
  std::vector<float> b;
  std::vector< unsigned long > a1;
  std::vector< unsigned long > b1;
  m_Geometry.push_back(a);
  m_Geometry.push_back(b);
  m_Topology.push_back(a1);
  m_Topology.push_back(b1);
}

// -------------------------------------------------------------------------
Mesh::
Mesh( const std::string& fname, float r, float g, float b  )
{
  this->setColor(r,g,b);
  this->m_TFileName = " ";
  std::vector<float> a;
  std::vector<float> x;
  std::vector<float> c;
  std::vector< unsigned long > a1;
  std::vector< unsigned long > b1;
  std::vector< unsigned long > c1;
  m_Geometry.push_back(a);
  m_Geometry.push_back(x);
  m_Geometry.push_back(c);
  m_Topology.push_back(a1);
  m_Topology.push_back(b1);
  m_Topology.push_back(c1);
  // Open file and put its contents into a string buffer
  std::ifstream in( fname.c_str( ) );
  if( !in )
  {
    in.close( );
    throw std::runtime_error(
      std::string( "Error: Could not open \"" ) + fname + "\""
      );
  } // end if
  std::istringstream buffer(
    std::string(
      ( std::istreambuf_iterator< char >( in ) ),
      std::istreambuf_iterator< char >( )
      )
    );
  in.close( );

  // Read file
  buffer >> this;
}
// -------------------------------------------------------------------------
Mesh::
Mesh( const std::string& fname, const std::string& tname,float r, float g, float b  )
{
  this->m_TFileName = tname;
  this->setColor(r,g,b);
  std::vector<float> a;
  std::vector<float> x;
  std::vector<float> c;
  std::vector< unsigned long > a1;
  std::vector< unsigned long > b1;
  std::vector< unsigned long > c1;
  m_Geometry.push_back(a);
  m_Geometry.push_back(x);
  m_Geometry.push_back(c);
  m_Topology.push_back(a1);
  m_Topology.push_back(b1);
  m_Topology.push_back(c1);
  // Open file and put its contents into a string buffer
  std::ifstream in( fname.c_str( ) );
  if( !in )
  {
    in.close( );
    throw std::runtime_error(
      std::string( "Error: Could not open \"" ) + fname + "\""
      );
  } // end if
  std::istringstream buffer(
    std::string(
      ( std::istreambuf_iterator< char >( in ) ),
      std::istreambuf_iterator< char >( )
      )
    );
  in.close( );

  // Read file
  buffer >> this;
}

// -------------------------------------------------------------------------
Mesh::
~Mesh( )
{
    if(this->m_VboId != 0)
        deleteVBO(this->m_VboId);
    if(this->m_IboId != 0)
        deleteVBO(this->m_IboId);
    if(this->m_TexId != 0)
        deleteVBO(this->m_TexId);
    this->m_IboId = this->m_VboId =this->m_TexId = 0;
}

void Mesh::
changeVboSup()
{
    this->m_VboSup = !this->m_VboSup;
}

void Mesh::
deleteVBO(GLuint vboId)
{
    glDeleteBuffers(1, &vboId);
}

// -------------------------------------------------------------------------
unsigned long Mesh::
getNumberOfPoints( int geo ) const
{
  return( this->m_Geometry[geo].size( ) / 3 );
}

// -------------------------------------------------------------------------
float* Mesh::
getPoint(int geo, unsigned long i )
{
  return( this->m_Geometry[geo].data( ) + ( i * 3 ) );
}

// -------------------------------------------------------------------------
const float* Mesh::
getPoint(int geo, unsigned long i ) const
{
  return( this->m_Geometry[geo].data( ) + ( i * 3 ) );
}

// -------------------------------------------------------------------------
void Mesh::
getPoint(int geo, unsigned long i, float* p ) const
{
  std::memcpy( p, this->getPoint(geo, i ), 3 * sizeof( float ) );
}

// -------------------------------------------------------------------------
void Mesh::
getPoint(int geo, unsigned long i, double* p ) const
{
  const float* fp = this->getPoint( geo, i );
  p[ 0 ] = double( fp[ 0 ] );
  p[ 1 ] = double( fp[ 1 ] );
  p[ 2 ] = double( fp[ 2 ] );
}

// -------------------------------------------------------------------------
unsigned long Mesh::
addPoint(int geo, float x, float y, float z )
{
  this->m_Geometry[geo].push_back( x );
  this->m_Geometry[geo].push_back( y );
  this->m_Geometry[geo].push_back( z );
  return( this->getNumberOfPoints( geo ) - 1 );

}

// -------------------------------------------------------------------------
unsigned long Mesh::
addPoint(int geo, double x, double y, double z )
{
  this->m_Geometry[geo].push_back( float( x ) );
  this->m_Geometry[geo].push_back( float( y ) );
  this->m_Geometry[geo].push_back( float( z ) );
  return( this->getNumberOfPoints(geo) - 1 );
}

// -------------------------------------------------------------------------
unsigned long Mesh::
addPoint(int geo, float* p )
{
  return( this->addPoint(geo, p[ 0 ], p[ 1 ], p[ 2 ] ) );
}

// -------------------------------------------------------------------------
unsigned long Mesh::
addPoint(int geo, double* p )
{
  return( this->addPoint(geo, p[ 0 ], p[ 1 ], p[ 2 ] ) );
}

// -------------------------------------------------------------------------
void Mesh::
setPoint(int geo, unsigned long i, float x, float y, float z )
{
  float* fp = this->getPoint(geo, i );
  fp[ 0 ] = x;
  fp[ 1 ] = y;
  fp[ 2 ] = z;
}

// -------------------------------------------------------------------------
void Mesh::
setPoint(int geo, unsigned long i, double x, double y, double z )
{
  float* fp = this->getPoint(geo, i );
  fp[ 0 ] = float( x );
  fp[ 1 ] = float( y );
  fp[ 2 ] = float( z );
}

// -------------------------------------------------------------------------
void Mesh::
setPoint(int geo, unsigned long i, float* p )
{
  std::memcpy( this->getPoint(geo, i ), p, 3 * sizeof( float ) );
}

// -------------------------------------------------------------------------
void Mesh::
setPoint(int geo, unsigned long i, double* p )
{
  float* fp = this->getPoint(geo, i );
  fp[ 0 ] = float( p[ 0 ] );
  fp[ 1 ] = float( p[ 1 ] );
  fp[ 2 ] = float( p[ 2 ] );
}

// -------------------------------------------------------------------------
#define Mesh_addFace_IMPL( _tp_, _c_, _t_ )                                   \
  template<>                                                            \
  void Mesh::                                                           \
  addFace< std::_c_< unsigned _t_ > >(                                  \
    int tp,                                                             \
    const std::_c_< unsigned _t_ >& f                                   \
    )                                                                   \
  {                                                                     \
    this->m_Topology[tp].push_back( f.size( ) );                            \
    for( const unsigned _t_& v: f )                                     \
      this->m_Topology[tp].push_back( ( unsigned long )( v ) );             \
  }
Mesh_addFace_IMPL(int tp, deque, char );
Mesh_addFace_IMPL(int tp, deque, short );
Mesh_addFace_IMPL(int tp, deque, int );
Mesh_addFace_IMPL(int tp, deque, long );
Mesh_addFace_IMPL(int tp, deque, long long );

Mesh_addFace_IMPL(int tp, list, char );
Mesh_addFace_IMPL(int tp, list, short );
Mesh_addFace_IMPL(int tp, list, int );
Mesh_addFace_IMPL(int tp, list, long );
Mesh_addFace_IMPL(int tp, list, long long );

Mesh_addFace_IMPL(int tp, vector, char );
Mesh_addFace_IMPL(int tp, vector, short );
Mesh_addFace_IMPL(int tp, vector, int );
Mesh_addFace_IMPL(int tp, vector, long );
Mesh_addFace_IMPL(int tp, vector, long long );

// -------------------------------------------------------------------------
float* Mesh::
getColor( )
{
  return( this->m_Color );
}

// -------------------------------------------------------------------------
const float* Mesh::
getColor( ) const
{
  return( this->m_Color );
}

// -------------------------------------------------------------------------
void Mesh::
getColor( float* p ) const
{
  std::memcpy( p, this->m_Color, 3 * sizeof( float ) );
}
// -------------------------------------------------------------------------
void Mesh::
drawInOpenGLContext( GLenum mode )
{
    if(this->m_TexCoords.size() == 0 || this->m_TFileName.compare(" ") == 0)
    {

                 // bind VBOs with IDs and set the buffer offsets of the bound VBOs
                // When buffer object is bound with its ID, all pointers in gl*Pointer()
                // are treated as offset instead of real pointer.
                glBindBuffer(GL_ARRAY_BUFFER, this->m_VboId);
                glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, this->m_IboId);

                // enable vertex arrays
                glEnableClientState(GL_NORMAL_ARRAY);
                glEnableClientState(GL_COLOR_ARRAY);
                glEnableClientState(GL_VERTEX_ARRAY);

                // before draw, specify vertex and index arrays with their offsets
                glNormalPointer(GL_FLOAT, 0, (void*)( sizeof(Vertex3)*this->m_Vertices.size()));
                glColorPointer(3, GL_FLOAT, 0, (void*)(sizeof(Vertex3)*this->m_Vertices.size()+sizeof(Vertex3)*this->m_Normals.size()));
                glVertexPointer(3, GL_FLOAT, 0, 0);
                glDrawElements(mode,            // primitive type
                               this->m_Indices.size(),                      // # of indices
                               GL_UNSIGNED_SHORT,         // data type
                               (void*)0);               // ptr to indices

                glDisableClientState(GL_VERTEX_ARRAY);  // disable vertex arrays
                glEnableClientState(GL_COLOR_ARRAY);
                glDisableClientState(GL_NORMAL_ARRAY);

                // it is good idea to release VBOs with ID 0 after use.
                // Once bound with 0, all pointers in gl*Pointer() behave as real
                // pointer, so, normal vertex array operations are re-activated
                glBindBuffer(GL_ARRAY_BUFFER, 0);
                glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    }
    else
    {
        if(this->m_VboSup) // draw cube using VBO
        {
            // bind VBOs with IDs and set the buffer offsets of the bound VBOs
            // When buffer object is bound with its ID, all pointers in gl*Pointer()
            // are treated as offset instead of real pointer.
            glBindBuffer(GL_ARRAY_BUFFER, this->m_VboId);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, this->m_IboId);

            // enable vertex arrays
            glEnableClientState(GL_NORMAL_ARRAY);
            glEnableClientState(GL_COLOR_ARRAY);
            glEnableClientState(GL_TEXTURE_COORD_ARRAY);
            glEnableClientState(GL_VERTEX_ARRAY);

            // before draw, specify vertex and index arrays with their offsets
            glNormalPointer(GL_FLOAT, 0, (void*)(sizeof(Vertex3)*this->m_Vertices.size()));
            glColorPointer(3, GL_FLOAT, 0, (void*)(sizeof(Vertex3)*this->m_Vertices.size()+sizeof(Vertex3)*this->m_Normals.size()));
            glTexCoordPointer(2, GL_FLOAT, 0, (void*)(sizeof(Vertex3)*this->m_Vertices.size()+sizeof(Vertex3)*this->m_Normals.size()+sizeof(Vertex3)*this->m_Colors.size()));
            glVertexPointer(3, GL_FLOAT, 0, 0);

            glBindTexture(GL_TEXTURE_2D, this->m_TexId);
            glDrawElements(mode,            // primitive type
                           this->m_Indices.size(),                      // # of indices
                           GL_UNSIGNED_SHORT,         // data type
                           (void*)0);               // ptr to indices

            glDisableClientState(GL_VERTEX_ARRAY);  // disable vertex arrays
            glDisableClientState(GL_TEXTURE_COORD_ARRAY);
            glDisableClientState(GL_COLOR_ARRAY);
            glDisableClientState(GL_NORMAL_ARRAY);

            // it is good idea to release VBOs with ID 0 after use.
            // Once bound with 0, all pointers in gl*Pointer() behave as real
            // pointer, so, normal vertex array operations are re-activated
            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        }

        // draw a cube using vertex array method
        // notice that only difference between VBO and VA is binding buffers and offsets
        else
        {
            glEnableClientState(GL_NORMAL_ARRAY);
            glEnableClientState(GL_COLOR_ARRAY);
            glEnableClientState(GL_TEXTURE_COORD_ARRAY);
            glEnableClientState(GL_VERTEX_ARRAY);

            // before draw, specify vertex arrays
            glNormalPointer(GL_FLOAT, 0, &this->m_Normals[0]);
            glColorPointer(3, GL_FLOAT, 0, &this->m_Colors[0]);
            glTexCoordPointer(2, GL_FLOAT, 0, &this->m_TexCoords[0]);
            glVertexPointer(3, GL_FLOAT, 0, &this->m_Vertices[0]);

            glBindTexture(GL_TEXTURE_2D, m_TexId);
            glDrawElements(GL_TRIANGLES,            // primitive type
                       this->m_Indices.size(),                      // # of indices
                       GL_UNSIGNED_SHORT,         // data type
                       (void*)&this->m_Indices[0]);         // ptr to indices

            glDisableClientState(GL_VERTEX_ARRAY);  // disable vertex arrays
            glDisableClientState(GL_TEXTURE_COORD_ARRAY);
            glDisableClientState(GL_COLOR_ARRAY);
            glDisableClientState(GL_NORMAL_ARRAY);
        }
    }

}
// -------------------------------------------------------------------------
void Mesh::
assignBuffers(  )
{
  unsigned long i = 0;
  std::vector<Vertex3> vertices;
  std::vector<Vertex3> normals;
  std::vector<Vertex2> textCoords;
  std::vector<Vertex3> colors;
  while( i < this->m_Topology[0].size( ) )
  {
      for( unsigned long j = 0; j < this->m_Topology[0][ i ]; ++j )
      {
          if(m_Topology[1].size()>0)
          {
              float * point = this->getPoint(1, this->m_Topology[1][ i + j + 1 ] - 1 );
              Vertex3 x;
              x.x = *point;
              x.y = *(point+1);
              x.z = *(point+2);
              normals.push_back(x);
          }

          if(m_Topology[2].size()>0)
          {
              float * point = this->getPoint(1, this->m_Topology[2][ i + j + 1 ] - 1 );
              Vertex2 x;
              x.x = *point;
              x.y = *(point+1);
              textCoords.push_back(x);
          }
          float * point2 = this->getPoint(0, this->m_Topology[0][ i + j + 1 ] - 1 );
          Vertex3 x2;
          x2.x = *point2;
          x2.y = *(point2+1);
          x2.z = *(point2+2);
          vertices.push_back(x2);
          Vertex3 xp;
          xp.x = this->m_Color[0];
          xp.y =  this->m_Color[1];
          xp.z =  this->m_Color[2];
          colors.push_back(xp);

      }
    i += this->m_Topology[0][ i ] + 1;
  } // end while
  if(this->m_Topology[2].size()==0 || this->m_TFileName.compare(" ") == 0)
  {
      indexVBO(vertices,normals,colors,this->m_Indices,this->m_Vertices,this->m_Normals,this->m_Colors);

       this->m_Geometry[0].clear();
       this->m_Geometry[1].clear();
       this->m_Geometry[2].clear();
       this->m_Topology[0].clear();
       this->m_Topology[1].clear();
       this->m_Topology[2].clear();
       glGenBuffers(1, &this->m_VboId);
       glBindBuffer(GL_ARRAY_BUFFER, this->m_VboId);
       glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex3)*this->m_Vertices.size()+sizeof(Vertex3)*this->m_Normals.size()+this->m_Colors.size()*sizeof(Vertex3), 0, GL_STATIC_DRAW);
       glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(Vertex3)*this->m_Vertices.size(), &this->m_Vertices[0]);                             // copy vertices starting from 0 offest
       glBufferSubData(GL_ARRAY_BUFFER, sizeof(Vertex3)*this->m_Vertices.size(), sizeof(Vertex3)*this->m_Normals.size(), &this->m_Normals[0]);                // copy normals after vertices
       glBufferSubData(GL_ARRAY_BUFFER,sizeof(Vertex3)*this->m_Vertices.size()+sizeof(Vertex3)*this->m_Normals.size(), this->m_Colors.size()*sizeof(Vertex3), &this->m_Colors[0]);
       glBindBuffer(GL_ARRAY_BUFFER, 0);
       glGenBuffers(1, &this->m_IboId);
       glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, this->m_IboId);
       glBufferData(GL_ELEMENT_ARRAY_BUFFER, this->m_Indices.size()*sizeof(unsigned short),&this->m_Indices[0] , GL_STATIC_DRAW);
       glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
  }
  else
  {
       indexVBO(vertices,normals,colors,textCoords,this->m_Indices,this->m_Vertices,this->m_Normals,this->m_Colors,this->m_TexCoords);
       this->m_Geometry[0].clear();
       this->m_Geometry[1].clear();
       this->m_Geometry[2].clear();
       this->m_Topology[0].clear();
       this->m_Topology[1].clear();
       this->m_Topology[2].clear();
        bool vboSup =this->m_VboSup= true;
        if(vboSup)
        {
            // create vertex buffer objects, you need to delete them when program exits
            // Try to put both vertex coords array, vertex normal array and vertex color in the same buffer object.
            // glBufferData with NULL pointer reserves only memory space.
            // Copy actual data with multiple calls of glBufferSubData for vertex positions, normals, colors, etc.
            // target flag is GL_ARRAY_BUFFER, and usage flag is GL_STATIC_DRAW
            glGenBuffers(1, &this->m_VboId);
            glBindBuffer(GL_ARRAY_BUFFER, this->m_VboId);
            glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex3)*this->m_Vertices.size()+sizeof(Vertex3)*this->m_Normals.size()+sizeof(Vertex3)*this->m_Colors.size()+sizeof(Vertex2)*this->m_TexCoords.size(), 0, GL_STATIC_DRAW);
            glBufferSubData(GL_ARRAY_BUFFER, 0,  sizeof(Vertex3)*this->m_Vertices.size(), &this->m_Vertices[0]);                                                    // copy vertices starting from 0 offest
            glBufferSubData(GL_ARRAY_BUFFER, sizeof(Vertex3)*this->m_Vertices.size(), sizeof(Vertex3)*this->m_Normals.size(), &this->m_Normals[0]);
            glBufferSubData(GL_ARRAY_BUFFER, sizeof(Vertex3)*this->m_Vertices.size()+sizeof(Vertex3)*this->m_Normals.size(),sizeof(Vertex3)*this->m_Colors.size(), &this->m_Colors[0]);                         // copy colours after normals                                       // copy normals after vertices
            glBufferSubData(GL_ARRAY_BUFFER,sizeof(Vertex3)*this->m_Vertices.size()+sizeof(Vertex3)*this->m_Normals.size()+sizeof(Vertex3)*this->m_Colors.size(), sizeof(Vertex2)*this->m_TexCoords.size(), &this->m_TexCoords[0]); // copy colours after normals
            glBindBuffer(GL_ARRAY_BUFFER, 0);

            glGenBuffers(1, &this->m_IboId);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, this->m_IboId);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned short)*this->m_Indices.size(), &this->m_Indices[0], GL_STATIC_DRAW);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

        }

        // load an bitmap from disk
        Image::Bmp bmp;
        bmp.read(this->m_TFileName.c_str());
        int imageWidth = bmp.getWidth();
        int imageHeight = bmp.getHeight();
        GLint format, internalFormat;
        int bitCount = bmp.getBitCount();
        switch(bitCount)
        {
            case 8:
                format = GL_LUMINANCE;
                internalFormat = GL_LUMINANCE8;
                break;
            case 24:
                format = GL_RGB;
                internalFormat = GL_RGB8;
                break;
            case 32:
                format = GL_RGBA;
                internalFormat = GL_RGBA8;
                break;
            default:
                format = GL_RGBA;
                internalFormat = GL_RGBA8;
        }

        // copy the texture to OpenGL
        glGenTextures(1, &this->m_TexId);

        // set active texture and configure it
        glBindTexture(GL_TEXTURE_2D, this->m_TexId);

        // select modulate to mix texture with color for shading
        glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE); // automatic mipmap generation included in OpenGL v1.4

        // copy bitmap data to texture object
        glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, imageWidth, imageHeight, 0, format, GL_UNSIGNED_BYTE, bmp.getDataRGB());
        // unbind
        glBindTexture(GL_TEXTURE_2D, 0);
      }

}

// -------------------------------------------------------------------------
void Mesh::
_strIn( std::istream& in )
{
  for(unsigned int i = 0; i < m_Geometry.size(); i++)
    this->m_Geometry[i].clear( );
  for(unsigned int i = 0; i < m_Topology.size(); i++)
    this->m_Topology[i].clear( );
  std::string line;
  std::getline( in, line );
  while( !in.eof( ) )
  {
    // Get command type
    std::istringstream str( line );
    std::string cmd;
    str >> cmd;

    // Process command
    if( cmd == "v" || cmd == "V" )
    {
      std::vector< float > p;
      while( !str.eof( ) )
      {
        float v;
        str >> v;
        p.push_back( v );
      } // end while
      this->addPoint(0, p.data( ) );
    }
    else if(cmd == "vn" || cmd == "VN" || cmd == "Vn" )
    {
       std::vector< float > p;
      while( !str.eof( ) )
      {
        float v;
        str >> v;
        p.push_back( v );
      } // end while
      this->addPoint(1, p.data( ) );
    }
    else if(cmd == "vt" || cmd == "VT" || cmd == "Vt" )
    {
       std::vector< float > p;
      while( !str.eof( ) )
      {
        float v;
        str >> v;
        p.push_back( v );
      } // end while
      this->addPoint(2, p.data( ) );
    }
    else if( cmd == "f" || cmd == "F" )
    {
      std::vector< unsigned long > f;
      std::vector< unsigned long > f2;
      std::vector< unsigned long > f3;
      std::string auxi;
      int tamV = 0;
      std::string s;
      str >> auxi;
      for(unsigned int i = 0; i < auxi.length(); i++)
      {
         if(auxi[i] == '/')
         {
             tamV++;
         }
      }
      tamV = tamV/2;
      s = str.str();
      std::replace(s.begin(), s.end(), '/', ' ');
      str.str(s);
      str >> cmd;
      while( !str.eof( ) )
      {
        unsigned long v;
        if(tamV == 0)
        {
            str >> v;
            f.push_back(v);
        }
        else if(tamV == 1)
        {
            str >> v;
            f.push_back(v);
            str >> v;
            f2.push_back(v);
        }
        else if(tamV == 2)
        {
            str >> v;
            f.push_back(v);
            str >> v;
            f3.push_back(v);
            str >> v;
            f2.push_back(v);
        }


      } // end while
      if (tamV == 0)
      {
          this->addFace(1,f);
      }
      else if(tamV == 1)
      {
          this->addFace(0,f);
          this->addFace(1,f2);

      }
      else if(tamV == 2)
      {
          this->addFace(0,f);
          this->addFace(1,f2);
          this->addFace(2,f3);
      }

    } // end if

    // Try next line
    std::getline( in, line );
  } // end while
  assignBuffers();
}

// -------------------------------------------------------------------------
void Mesh::
_strOut( std::ostream& out ) const
{
  // Stream geometry
  unsigned long i = 0;
  for( i = 0; i < this->m_Geometry[0].size( ); ++i )
  {
      if( i % 3 == 0 )
        out << std::endl << "v ";
      out << this->m_Geometry[0][ i ];
  } // end for
  for( i = 0; i < this->m_Geometry[1].size( ); ++i )
  {
      if( i % 3 == 0 )
        out << std::endl << "vn ";
      out << this->m_Geometry[1][ i ];
  } // end for

  // Stream topology
  out << std::endl;
  i = 0;
  while( i < this->m_Topology.size( ) )
  {
    out << std::endl << "f ";
    for( unsigned long j = 0; j < this->m_Topology[0][i]; ++j )
      out << this->m_Topology[0][ i + j + 1 ] << "//" <<this->m_Topology[1][ i + j + 1 ] << " " ;
    i += this->m_Topology[0][ i ];
  } // end while
}





bool Mesh::
getSimilarVertexIndex_fast(
	PackedVertex & packed,
	std::map<PackedVertex,unsigned short> & VertexToOutIndex,
	unsigned short & result
){
	std::map<PackedVertex,unsigned short>::iterator it = VertexToOutIndex.find(packed);
	if ( it == VertexToOutIndex.end() ){
		return false;
	}else{
		result = it->second;
		return true;
	}
}


void Mesh::
indexVBO(
	std::vector<Vertex3> & in_vertices,
	std::vector<Vertex3> & in_normals,
	std::vector<Vertex3> & in_colors,

	std::vector<unsigned short> & out_indices,
	std::vector<Vertex3> & out_vertices,
	std::vector<Vertex3> & out_normals,
	std::vector<Vertex3> & out_colors
){
	std::map<PackedVertex,unsigned short> VertexToOutIndex;

	// For each input vertex
	for ( unsigned int i=0; i<in_vertices.size(); i++ ){

		PackedVertex packed = {in_vertices[i], in_normals[i],in_colors[i]};


		// Try to find a similar vertex in out_XXXX
		unsigned short index;
		bool found = getSimilarVertexIndex_fast( packed, VertexToOutIndex, index);

		if ( found ){ // A similar vertex is already in the VBO, use it instead !
			out_indices.push_back( index );
		}else{ // If not, it needs to be added in the output data.
			out_vertices.push_back( in_vertices[i]);
			out_normals .push_back( in_normals[i]);
			out_colors .push_back( in_colors[i]);
			unsigned short newindex = (unsigned short)out_vertices.size() - 1;
			out_indices .push_back( newindex );
			VertexToOutIndex[ packed ] = newindex;
		}
	}
}

bool Mesh::
getSimilarVertexIndex_fast(
	PackedVertex2 & packed,
	std::map<PackedVertex2,unsigned short> & VertexToOutIndex,
	unsigned short & result
){
	std::map<PackedVertex2,unsigned short>::iterator it = VertexToOutIndex.find(packed);
	if ( it == VertexToOutIndex.end() ){
		return false;
	}else{
		result = it->second;
		return true;
	}
}


void Mesh::
indexVBO(
	std::vector<Vertex3> & in_vertices,
	std::vector<Vertex3> & in_normals,
	std::vector<Vertex3> & in_colors,
	std::vector<Vertex2> & in_textCoords,

	std::vector<unsigned short> & out_indices,
	std::vector<Vertex3> & out_vertices,
	std::vector<Vertex3> & out_normals,
	std::vector<Vertex3> & out_colors,
	std::vector<Vertex2> & out_textCoords
){
	std::map<PackedVertex2,unsigned short> VertexToOutIndex;

	// For each input vertex
	for ( unsigned int i=0; i<in_vertices.size(); i++ ){

		PackedVertex2 packed = {in_vertices[i], in_normals[i],in_colors[i],in_textCoords[i]};


		// Try to find a similar vertex in out_XXXX
		unsigned short index;
		bool found = getSimilarVertexIndex_fast( packed, VertexToOutIndex, index);

		if ( found ){ // A similar vertex is already in the VBO, use it instead !
			out_indices.push_back( index );
		}else{ // If not, it needs to be added in the output data.
			out_vertices.push_back( in_vertices[i]);
			out_normals .push_back( in_normals[i]);
			out_colors .push_back( in_colors[i]);
			out_textCoords .push_back( in_textCoords[i]);
			unsigned short newindex = (unsigned short)out_vertices.size() - 1;
			out_indices .push_back( newindex );
			VertexToOutIndex[ packed ] = newindex;
		}
	}
}
// eof - Mesh.cxx

