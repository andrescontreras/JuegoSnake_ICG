#ifndef __Banana__h__
#define __Banana__h__

#include "Object.h"
#include <GL/glut.h>
#include <vector>
#include <utility>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
class Banana: public Object
{
public:
    Banana(const std::string& fname, Mesh** omesh);
    virtual ~Banana();

    bool placeBanana(std::vector<std::tuple<int,int,int>> notPosible);

    virtual void drawInOpenGLContext(GLenum mode);

protected:
    float      m_RotationSpeed;
};

#endif // __Banana__h__

// eof - Banana.h

