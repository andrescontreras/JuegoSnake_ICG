// -------------------------------------------------------------------------
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// -------------------------------------------------------------------------
#ifndef __Camera__h__
#define __Camera__h__

#include "Vector.h"
#include <fstream>

/**
 */
class Camera
{
public:
  //! Memory management
  //@{
  Camera( );
  virtual ~Camera( );
  //@}

  void move( const Vector& dir );
  void         rotateX(const float& angle);
  void         rotateY(const float& angle);
  void         rotateZ(const float& angle);
  void         setQuaternionAxis(Vector n_QuaternionAxis);
  void         setQuaternionReal(float  n_QuaternionReal);
  Vector       getQuaternionAxis();
  float        getQuaternionReal();
  void         placeCamera(int times, int direction, int nextDirection, int coordX,int coordY,int coordZ);
  void increaseAngleX();
  void decreaseAngleX();
  void increaseAngleY();
  void decreaseAngleY();
  void increaseZoom();
  void decreaseZoom();


  void forward( float d );
  void upward( float d );
  void strafe( float d );

  void getReference( int& dx, int& dy, int x, int y );
  void setReference( int x, int y );

  void loadCameraMatrix(float posX, float posY, float posZ, float targetX, float targetY, float targetZ);

  void setFOV( float a );
  void setAngles( int x, int y );
  void setZoom( int a );
  void setPlanes( float n, float f );
  void setWindow( int w, int h );
  void loadProjectionMatrix( );

protected:
  float m_FOV;
  float m_Near;
  float m_Far;
  float m_QuaternionReal;
  int m_AngleX;
  int m_AngleY;
  int m_Zoom;
  int m_WindowWidth;
  int m_WindowHeight;

  Vector      m_QuaternionAxis;
  Vector m_Focus;
  Vector m_RightVector;
  Vector m_UpVector;
  Vector m_Position;
  Vector m_Rotations;

  int m_RefX;
  int m_RefY;
};

#endif // __Camera__h__

// eof - Camera.h


