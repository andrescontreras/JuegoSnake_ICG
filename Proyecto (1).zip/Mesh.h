// -------------------------------------------------------------------------
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// -------------------------------------------------------------------------
#ifndef __Mesh__h__
#define __Mesh__h__
#define GL_GLEXT_PROTOTYPES
#include <iostream>
#include <vector>
#include <map>
#include <GL/glut.h>
#include "glExtension.h"
#include "Bmp.h"
#include <cstring>
#include <deque>
#include <fstream>
#include <list>
#include <sstream>
#include <stdexcept>
#include <string>
#include <algorithm>

typedef struct
{
    GLfloat x, y;
}
Vertex2;
typedef struct
{
    GLfloat x, y, z;
}
Vertex3;
struct PackedVertex{
	Vertex3 position;
	Vertex3 normal;
	Vertex3 color;
	bool operator<(const PackedVertex that) const{
		return memcmp((void*)this, (void*)&that, sizeof(PackedVertex))>0;
	};
};
struct PackedVertex2{
	Vertex3 position;
	Vertex3 normal;
	Vertex3 color;
	Vertex2 textCoord;
	bool operator<(const PackedVertex2 that) const{
		return memcmp((void*)this, (void*)&that, sizeof(PackedVertex2))>0;
	};
};

/**
 */
class Mesh
{
public:
  //! Streaming methods
  //@{
  friend std::istream& operator>>( std::istream& i, Mesh& s )
    {
      s._strIn( i );
      return( i );
    }

  friend std::istream& operator>>( std::istream& i, Mesh* s )
    {
      s->_strIn( i );
      return( i );
    }

  friend std::ostream& operator<<( std::ostream& o, const Mesh& s )
    {
      s._strOut( o );
      return( o );
    }

  friend std::ostream& operator<<( std::ostream& o, const Mesh* s )
    {
      s->_strOut( o );
      return( o );
    }
  //@}

public:
  //! Memory management
  //@{
  Mesh( );
  Mesh( const std::string& fname , float r,float g,float b);
  Mesh( const std::string& fname, const std::string& tname,float r, float g, float b  );
  virtual ~Mesh( );
  //@}

  //! Geometry-related methods
  //@{
  unsigned long getNumberOfPoints(int geo) const;
  float* getPoint(int geo, unsigned long i );
  const float* getPoint(int geo, unsigned long i ) const;
  void getPoint(int geo, unsigned long i, float* p ) const;
  void getPoint(int geo, unsigned long i, double* p ) const;

  unsigned long addPoint(int geo, float x, float y, float z );
  unsigned long addPoint(int geo, double x, double y, double z );
  unsigned long addPoint(int geo, float* p );
  unsigned long addPoint(int geo, double* p );

  void setPoint(int geo, unsigned long i, float x, float y, float z );
  void setPoint(int geo, unsigned long i, double x, double y, double z );
  void setPoint(int geo, unsigned long i, float* p );
  void setPoint(int geo, unsigned long i, double* p );
  //@}


  //! Topology-related methods
  //@{
  template< class _TContainer >
  void addFace(int tp, const _TContainer& f );

  template< class _TIterator >
  inline void addFace(int tp, _TIterator b, _TIterator e )
    {
      std::vector< unsigned long > f;
      for( _TIterator i = b; i != e; ++i )
        f.push_back( ( unsigned long )( *i ) );
      this->addFace(tp, f );
    }

  //! vector+natural+variadic arguments
  template< class _TNatural, class... _TArgs >
  inline void addFace(
    int tp,
    std::vector< unsigned long >& f,
    const _TNatural& x,
    _TArgs... args
    )
    {
      f.push_back( ( unsigned long )( x ) );
      this->addFace(tp, f, args... );
    }

  //! natural+variadic arguments
  template< class _TNatural, class... _TArgs >
  inline void addFace(int tp, const _TNatural& x, _TArgs... args )
    {
      std::vector< unsigned long > f;
      f.push_back( ( unsigned long )( x ) );
      this->addFace(tp, f, args... );
    }
  //@}

  //! Colors
  //@{
  float* getColor( );
  const float* getColor( ) const;
  void getColor( float* p ) const;
  void changeVboSup();
  template< class _TRed, class _TGreen, class _TBlue >
  inline void setColor( _TRed r, _TGreen g, _TBlue b )
    {
      this->m_Color[ 0 ] = float( r );
      this->m_Color[ 1 ] = float( g );
      this->m_Color[ 2 ] = float( b );
    }
  //@}

  //! All the magic happens here
  virtual void drawInOpenGLContext( GLenum mode );
  virtual void assignBuffers();
  virtual bool getSimilarVertexIndex_fast( PackedVertex & packed, std::map<PackedVertex,unsigned short> & VertexToOutIndex, unsigned short & result);
  virtual void indexVBO( std::vector<Vertex3> & in_vertices, std::vector<Vertex3> & in_normals,std::vector<Vertex3> & in_colors, std::vector<unsigned short> & out_indices, std::vector<Vertex3> & out_vertices, std::vector<Vertex3> & out_normals,std::vector<Vertex3> & out_colors);
  virtual bool getSimilarVertexIndex_fast( PackedVertex2 & packed, std::map<PackedVertex2,unsigned short> & VertexToOutIndex, unsigned short & result);
  virtual void indexVBO( std::vector<Vertex3> & in_vertices, std::vector<Vertex3> & in_normals,std::vector<Vertex3> & in_colors,std::vector<Vertex2> & in_textCoords, std::vector<unsigned short> & out_indices, std::vector<Vertex3> & out_vertices, std::vector<Vertex3> & out_normals,std::vector<Vertex3> & out_colors,std::vector<Vertex2> & out_textCoords);
  virtual void deleteVBO(GLuint vboId);

protected:
  //! Here's where the real streaming is done
  //@{
  void _strIn( std::istream& in );
  void _strOut( std::ostream& out ) const;
  //@}

protected:
  std::vector<std::vector< GLfloat >>          m_Geometry;
  std::vector<std::vector< unsigned long >>    m_Topology;
  std::vector<Vertex3>                         m_Vertices;
  std::vector<Vertex3>                         m_Normals;
  std::vector<Vertex2>                         m_TexCoords;
  std::vector<unsigned short>                  m_Indices;
  std::vector<Vertex3>                         m_Colors;
  GLuint                                       m_VboId ;                   // ID of VBO for vertex arrays
  GLuint                                       m_TexId;
  GLuint                                       m_IboId;
  std::string                                  m_TFileName;
  bool                                         m_VboSup;

  float                        m_Color[ 3 ];
};

#endif // __Mesh__h__

// eof - Mesh.h


