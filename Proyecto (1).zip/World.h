#ifndef __World__h__
#define __World__h__

#include "Banana.h"
#include "Obstacle.h"
#include "Conga.h"
#include "Mesh.h"
#include "Skybox.h"
#include "Camera.h"
#include <GL/glut.h>
#include <tuple>

class World
{
public:
    World(int level);
    virtual ~World();

    bool moveMonkeys(int dir, int jump);
    int  getSizeofConga();
    void placeCamera();
    void getBananaCoords(int& coordX, int& coordY);
    void changeVboSup();

    virtual void drawInOpenGLContext(GLenum mode,bool fpc);

protected:
    Banana*         m_Banana;
    Obstacle*       m_Obstacle;
    Conga*          m_Conga;
    Mesh*           m_BananaMesh;
    Camera*         m_Camera;
    Skybox*          m_Skybox;
};

#endif // __World__h__

// eof - World.h
