#include "Skybox.h"



Skybox::
Skybox()
{
  this->m_Floor = new Tile("Textures/FloorTexture.bmp");
  this->m_Sky = new Tile("Textures/SkyTexture.bmp");
  this->m_Boundary = new Tile("Textures/SkyTexture.bmp");
}

Skybox::
~Skybox()
{
    delete(this->m_Floor);
    delete(this->m_Sky);
    delete(this->m_Boundary);
}

void Skybox::
drawInOpenGLContext(GLenum mode)
{
    glPushMatrix();
    glTranslatef(0,-1.2,0);
    glScalef(65,0.5,65);
    this->m_Floor->drawInOpenGLContext(mode);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0,8,0);
    glScalef(70,0.5,70);
    this->m_Sky->drawInOpenGLContext(mode);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(35,0,0);
    glScalef(0.5,20,70);
    this->m_Boundary->drawInOpenGLContext(mode);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-35,0,0);
    glScalef(0.5,20,70);
    this->m_Boundary->drawInOpenGLContext(mode);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0,0,35);
    glScalef(70,20,0.5);
    this->m_Boundary->drawInOpenGLContext(mode);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0,0,-35);
    glScalef(70,20,0.5);
    this->m_Boundary->drawInOpenGLContext(mode);
    glPopMatrix();
}
