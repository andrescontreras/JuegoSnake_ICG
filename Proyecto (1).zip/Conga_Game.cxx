///////////////////////////////////////////////////////////////////////////////
// main.cpp
// ========
// testing OpenGL buffer object, GL_ARB_vertex_buffer_object extension
// draw a unit cube using glDrawElements()
//
//  AUTHOR: Song Ho Ahn (song.ahn@gmail.com)
// CREATED: 2006-11-14
// UPDATED: 2018-08-09
///////////////////////////////////////////////////////////////////////////////

// in order to get function prototypes from glext.h, define GL_GLEXT_PROTOTYPES before including glext.h
#define GL_GLEXT_PROTOTYPES

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "glExtension.h"                // helper for OpenGL extensions
#include "World.h"
#include "Tile.h"


// GLUT CALLBACK functions
void displayCB();
void reshapeCB(int w, int h);
void timerCB(int millisec);
void idleCB();
void keyboardCB(unsigned char key, int x, int y);
void specialKeyboardCbk( int key, int x, int y);
void mouseCB(int button, int stat, int x, int y);
void mouseMotionCB(int x, int y);

// CALLBACK function when exit() called ///////////////////////////////////////
void exitCB();


void initGL();
int  initGLUT(int argc, char **argv);
bool initSharedMem();
void initMenu();
void initGame(int level);
void initLights();
void loadScores();
void writeScores(double score);
void setCamera(float posX, float posY, float posZ, float targetX, float targetY, float targetZ);
void drawString(const char *str, int x, int y, float color[4], void *font);
void showInfo();
void showMenu();
void toOrtho();
void toPerspective();


// constants
const int   SCREEN_WIDTH    = 800;
const int   SCREEN_HEIGHT   = 600;
const float CAMERA_DISTANCE = 10.0f;
const int   TEXT_WIDTH      = 8;
const int   TEXT_HEIGHT     = 13;
const int   TEXT_WIDTH2      = 9;
const int   TEXT_HEIGHT2     = 18;
const int   TEXT_HEIGHT3     = 24;


// global variables
void *font = GLUT_BITMAP_8_BY_13;
void *font2 = GLUT_BITMAP_HELVETICA_18;
void *font3 = GLUT_BITMAP_TIMES_ROMAN_24;
int dir;
int jump;
int TextSelected;
int LevelSelected;
int dif;
bool pause;
bool menu;
bool fpc;
bool pauseLose;
double score;
std::chrono::time_point< std::chrono::high_resolution_clock > m_Countdown;
int screenWidth;
int screenHeight;
bool mouseLeftDown;
bool mouseRightDown;
float mouseX, mouseY;
float cameraAngleX;
float cameraAngleY;
float cameraDistance;
bool vboSupported, vboUsed;
int drawMode = 0;
double scoreLevel1;
double scoreLevel2;
double scoreLevel3;
double scoreLevel4;
double scoreLevel5;
World* myWorld = nullptr;
Tile* myMenu = nullptr;





///////////////////////////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
    initSharedMem();

    // init GLUT and GL
    initGLUT(argc, argv);
    initGL();

    // register exit callback
    atexit(exitCB);

    // get OpenGL info
    glExtension& ext = glExtension::getInstance();
    vboSupported = vboUsed = ext.isSupported("GL_ARB_vertex_buffer_object");
    if(vboSupported)
    {
        loadScores();
        initMenu();
        std::cout << "Video card supports GL_ARB_vertex_buffer_object." << std::endl;
    }
    else
    {
        std::cout << "[WARNING] Video card does NOT support GL_ARB_vertex_buffer_object." << std::endl;
    }
    // the last GLUT call (LOOP)
    // window will be shown and display callback is triggered by events
    // NOTE: this call never return main().
    glutMainLoop(); /* Start GLUT event-processing loop */

    return 0;
}

void initMenu()
{
    TextSelected = 0;
    LevelSelected = 1;
    cameraAngleX = cameraAngleY = 0.0f;
    cameraDistance = CAMERA_DISTANCE;
    if(myMenu != nullptr)
        delete (myMenu);
    myMenu = new Tile("Textures/Menu.bmp");
    menu = true;
}
void initGame(int level)
{
    dif = 0;
    menu = false;
    pause = false;
    pauseLose = false;
    score = 0;
    dir = 1;
    jump = 0;
    fpc = true;
    if(myWorld != nullptr)
        delete (myWorld);
    myWorld = new World(level);
    m_Countdown = std::chrono::high_resolution_clock::now( );
}
///////////////////////////////////////////////////////////////////////////////
// initialize GLUT for windowing
///////////////////////////////////////////////////////////////////////////////
int initGLUT(int argc, char **argv)
{

    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);   // display mode

    glutInitWindowSize(screenWidth, screenHeight);  // window size

    glutInitWindowPosition(100, 100);               // window location

    // finally, create a window with openGL context
    // Window will not displayed until glutMainLoop() is called
    // it returns a unique ID
    int handle = glutCreateWindow("CONGA");         // param is the title of window

    // register GLUT callback functions
    glutDisplayFunc(displayCB);
    glutTimerFunc(33, timerCB, 33);                 // redraw only every given millisec
    glutIdleFunc(idleCB);                           // redraw when idle
    glutReshapeFunc(reshapeCB);
    glutKeyboardFunc(keyboardCB);
    glutSpecialFunc(specialKeyboardCbk);
    glutMouseFunc(mouseCB);
    glutMotionFunc(mouseMotionCB);

    return handle;
}



///////////////////////////////////////////////////////////////////////////////
// initialize OpenGL
// disable unused features
///////////////////////////////////////////////////////////////////////////////
void initGL()
{
    glShadeModel(GL_SMOOTH);                    // shading mathod: GL_SMOOTH or GL_FLAT
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);      // 4-byte pixel alignment

    // enable /disable features
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    //glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    //glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_NORMALIZE);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_CULL_FACE);

     // track material ambient and diffuse from surface color, call it before glEnable(GL_COLOR_MATERIAL)
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);

    glClearColor(0, 0, 0, 0);                   // background color
    glClearStencil(0);                          // clear stencil buffer
    glClearDepth(1.0f);                         // 0 is near, 1 is far
    glDepthFunc(GL_LEQUAL);

    initLights();
}





///////////////////////////////////////////////////////////////////////////////
// initialize global variables
///////////////////////////////////////////////////////////////////////////////
bool initSharedMem()
{
    screenWidth = SCREEN_WIDTH;
    screenHeight = SCREEN_HEIGHT;

    mouseLeftDown = mouseRightDown = false;
    mouseX = mouseY = 0;

    drawMode = 0; // 0:fill, 1: wireframe, 2:points

    return true;
}






///////////////////////////////////////////////////////////////////////////////
// initialize lights
///////////////////////////////////////////////////////////////////////////////
void initLights()
{
    // set up light colors (ambient, diffuse, specular)
    GLfloat lightKa[] = {.2f, .2f, .2f, 1.0f};  // ambient light
    GLfloat lightKd[] = {.6f, .6f, .6f, 1.0f};  // diffuse light
    GLfloat lightKs[] = {.3f, .3f, .3f, 1.0f};           // specular light
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightKa);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightKd);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightKs);

    // position the light
    float lightPos[4] = {1, 1, 1, 0}; // directional light
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

    glEnable(GL_LIGHT0);                           // MUST enable each light source after configuration
}



///////////////////////////////////////////////////////////////////////////////
// set camera position and lookat direction
///////////////////////////////////////////////////////////////////////////////
void setCamera(float posX, float posY, float posZ, float targetX, float targetY, float targetZ)
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(posX, posY, posZ, targetX, targetY, targetZ, 0, 1, 0); // eye(x,y,z), focal(x,y,z), up(x,y,z)
}






//=============================================================================
// CALLBACKS
//=============================================================================
void displayCB()
{
    // clear buffer
    if(!menu)
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
        glPushMatrix();
        if (fpc)
        {
            setCamera(0.25,0.44,0,4,0,0);
            myWorld->placeCamera();
        }
        else
        {
            setCamera(0,30,35,0,0,0);
            glTranslatef(0, 0, -cameraDistance);
            glRotatef(cameraAngleX, 1, 0, 0);   // pitch
            glRotatef(cameraAngleY, 0, 1, 0);   // heading
        }

        if(vboUsed) // draw cube using VBO
        {
            myWorld->drawInOpenGLContext(GL_POLYGON,fpc);
        }


        // draw info messages
        showInfo();

        glPopMatrix();

        glutSwapBuffers();
    }
    else if(!pauseLose)
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
        glPushMatrix();
        setCamera(0,0,0,5,0,0);
        glTranslatef(0, 0, -10);
        glPushMatrix();
        glTranslatef(15,0.5,10.6);
        glScalef(9,9,9);
        myMenu->drawInOpenGLContext(GL_TRIANGLES);
        glPopMatrix();
        showMenu();
        glPopMatrix();
        glutSwapBuffers();
    }

}


void reshapeCB(int w, int h)
{
    screenWidth = w;
    screenHeight = h;
    toPerspective();
}


void timerCB(int millisec)
{
    glutTimerFunc(millisec, timerCB, millisec);
    glutPostRedisplay();
}


void idleCB()
{
    if(!menu)
    {
        double milisegundos =
                    std::chrono::duration_cast< std::chrono::milliseconds >(
                        std::chrono::high_resolution_clock::now( ) - m_Countdown
                        ).count( );
        if(!pause && milisegundos >= (250-dif))
        {
            glutPostRedisplay( );
            bool noPerdio = myWorld->moveMonkeys(dir,jump);
            int sizeConga =  myWorld->getSizeofConga();
            score += sizeConga*2;
            if(sizeConga == 10 && dif != 25)
            {
                dif = 25;
            }
            if(sizeConga == 20 && dif != 50)
            {
                dif = 50;
            }
            if(noPerdio)
            {
                if(jump == 1)
                    jump = 2;
                else if(jump == 2)
                    jump = 0;
                m_Countdown = std::chrono::high_resolution_clock::now( );
            }
            else
            {
                delete (myWorld);
                myWorld = nullptr;
                writeScores(score);
                pauseLose = true;
                initMenu();
            }

        }
    }
    else
        if(!pauseLose)
            glutPostRedisplay( );
}

// -------------------------------------------------------------------------
void specialKeyboardCbk( int key, int x, int y)
{
    if(!menu)
    {
        switch (key)
        {
        case GLUT_KEY_RIGHT:
            if(dir == 1)
            {
                dir = 3;
            }
            else if(dir == 2)
            {
                dir = 4;
            }
            else if(dir == 3)
            {
                dir = 2;
            }
            else if(dir == 4)
            {
                dir = 1;
            }
            break;
        case GLUT_KEY_LEFT:
            if(dir == 1)
            {
                dir = 4;
            }
            else if(dir == 2)
            {
                dir = 3;
            }
            else if(dir == 3)
            {
                dir = 1;
            }
            else if(dir == 4)
            {
                dir = 2;
            }
            break;
        }
    }
    else{
       switch (key)
        {
        case GLUT_KEY_UP:
            if(TextSelected != 0)
            {
                TextSelected--;
            }
            break;
        case GLUT_KEY_DOWN:
            if(TextSelected != 6)
            {
                TextSelected++;
            }
            break;
        }
    }
}
void keyboardCB(unsigned char key, int x, int y)
{
    if(!menu)
    {
        switch(key)
        {
        case 27: // ESCAPE
             delete (myWorld);
             myWorld = nullptr;
             writeScores(score);
             initMenu();
            break;
        case 'd': // switch rendering modes (fill -> wire -> point)
        case 'D':
            ++drawMode;
            drawMode %= 3;
            if(drawMode == 0)        // fill mode
            {
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
                glEnable(GL_DEPTH_TEST);
                glEnable(GL_CULL_FACE);
            }
            else if(drawMode == 1)  // wireframe mode
            {
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
                glDisable(GL_DEPTH_TEST);
                glDisable(GL_CULL_FACE);
            }
            else                    // point mode
            {
                glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
                glDisable(GL_DEPTH_TEST);
                glDisable(GL_CULL_FACE);
            }
            break;
        case 'p': case 'P':
        {
            pause = !pause;
        }
        break;
        case 'f': case 'F':
        {
            fpc = !fpc;
        }
        break;
        case ' ':
            if(jump != 1 && jump != 2)
            {
                jump = 1;
            }
            break;
        default:
            ;
        }
    }
    else
    {
       if(key == ' ' && !pauseLose)
       {
           if(TextSelected ==  0)
           {
               initGame(LevelSelected);
           }
           else if (TextSelected !=6)
           {
               LevelSelected = TextSelected;
           }
           else
           {
               exit(0);
           }
       }
       else if (key == ' ' && pauseLose)
       {
           pauseLose = false;
       }
       else if(key == 27)
       {
            exit(0);
       }
    }
}


void mouseCB(int button, int state, int x, int y)
{
    mouseX = x;
    mouseY = y;

    if(button == GLUT_LEFT_BUTTON)
    {
        if(state == GLUT_DOWN)
        {
            mouseLeftDown = true;
        }
        else if(state == GLUT_UP)
            mouseLeftDown = false;
    }

    else if(button == GLUT_RIGHT_BUTTON)
    {
        if(state == GLUT_DOWN)
        {
            mouseRightDown = true;
        }
        else if(state == GLUT_UP)
            mouseRightDown = false;
    }
}


void mouseMotionCB(int x, int y)
{
    if(mouseLeftDown)
    {
        cameraAngleY += (x - mouseX);
        cameraAngleX += (y - mouseY);
        mouseX = x;
        mouseY = y;
    }
    if(mouseRightDown)
    {
        cameraDistance -= (y - mouseY) * 0.2f;
        mouseY = y;
    }
}



///////////////////////////////////////////////////////////////////////////////
// write 2d text using GLUT
// The projection matrix must be set to orthogonal before call this function.
///////////////////////////////////////////////////////////////////////////////
void drawString(const char *str, int x, int y, float color[4], void *font)
{
    glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT); // lighting and color mask
    glDisable(GL_LIGHTING);     // need to disable lighting for proper text color
    glDisable(GL_TEXTURE_2D);

    glColor4fv(color);          // set text color
    glRasterPos2i(x, y);        // place text position

    // loop all characters in the string
    while(*str)
    {
        glutBitmapCharacter(font, *str);
        ++str;
    }

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
    glPopAttrib();
}





///////////////////////////////////////////////////////////////////////////////
// display info messages
///////////////////////////////////////////////////////////////////////////////
void showInfo()
{
    // backup current model-view matrix
    glPushMatrix();                     // save current modelview matrix
    glLoadIdentity();                   // reset modelview matrix

    // set to 2D orthogonal projection
    glMatrixMode(GL_PROJECTION);     // switch to projection matrix
    glPushMatrix();                  // save current projection matrix
    glLoadIdentity();                // reset projection matrix
    gluOrtho2D(0, screenWidth, 0, screenHeight);  // set to orthogonal projection

    float color[4] = {1, 1, 1, 1};

    std::stringstream ss;
    ss << "VBO: " << (vboUsed ? "on" : "off") << std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT, color, font);
    ss.str(""); // clear buffer
    int coordX;
    int coordY;
    myWorld->getBananaCoords(coordX,coordY);
    ss << "Banana - X:" << coordX << " Y:"<<coordY << std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT*2, color, font);
    ss.str(""); // clear buffer

    ss << myWorld->getSizeofConga() << " Monitos"<< std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT*3, color, font);
    ss.str("");

    ss << "Puntaje: "<< score << std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT*4, color, font);
    ss.str("");

    if(pauseLose)
    {
        ss << "Perdiste: "<< score << std::ends;  // add 0(ends) at the end
        drawString(ss.str().c_str(), (screenWidth/2), (screenHeight/2)+TEXT_HEIGHT3, color, font3);
    }

    // restore projection matrix
    glPopMatrix();                   // restore to previous projection matrix

    // restore modelview matrix
    glMatrixMode(GL_MODELVIEW);      // switch to modelview matrix
    glPopMatrix();                   // restore to previous modelview matrix
}
void showMenu()
{
    // backup current model-view matrix
    glPushMatrix();                     // save current modelview matrix
    glLoadIdentity();                   // reset modelview matrix

    glMatrixMode(GL_PROJECTION);     // switch to projection matrix
    glPushMatrix();                  // save current projection matrix
    glLoadIdentity();                // reset projection matrix
    gluOrtho2D(0, screenWidth, 0, screenHeight);  // set to orthogonal projection

    float color[4] = {1, 1, 1, 1};
    float color2[4] = {1, 0, 1, 1};
    float color3[4] = {1, 1, 0, 1};

    std::stringstream ss;
    ss << "Jugar" <<  std::ends;  // add 0(ends) at the end
    if (TextSelected != 0)
        drawString(ss.str().c_str(), (screenWidth/2)+3, (screenHeight/2)+TEXT_HEIGHT3, color, font3);
    else
        drawString(ss.str().c_str(), (screenWidth/2)+3, (screenHeight/2)+TEXT_HEIGHT3, color2, font3);
    ss.str(""); // clear buffer

    ss << "Nivel 1" << std::ends;
    if(TextSelected != 1 && LevelSelected != 1)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(2*TEXT_HEIGHT3), color, font3);
    else if((TextSelected == 1 && LevelSelected == 1) ||LevelSelected == 1)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(2*TEXT_HEIGHT3), color3, font3);
    else if (TextSelected == 1 && LevelSelected != 1)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(2*TEXT_HEIGHT3), color2, font3);
    ss.str("");
    ss << "Nivel 2"<< std::ends;
    if(TextSelected != 2 && LevelSelected != 2)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(3*TEXT_HEIGHT3), color, font3);
    else if((TextSelected == 2 && LevelSelected == 2) ||LevelSelected == 2)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(3*TEXT_HEIGHT3), color3, font3);
    else if (TextSelected == 2 && LevelSelected != 2)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(3*TEXT_HEIGHT3), color2, font3);
    ss.str("");
    ss << "Nivel 3"<< std::ends;
    if(TextSelected != 3 && LevelSelected != 3)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(4*TEXT_HEIGHT3), color, font3);
    else if((TextSelected == 3 && LevelSelected == 3) ||LevelSelected == 3)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(4*TEXT_HEIGHT3), color3, font3);
    else if (TextSelected == 3 && LevelSelected != 3)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(4*TEXT_HEIGHT3), color2, font3);
    ss.str("");
    ss << "Nivel 4"<< std::ends;
    if(TextSelected != 4 && LevelSelected != 4)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(5*TEXT_HEIGHT3), color, font3);
    else if((TextSelected == 4 && LevelSelected == 4) ||LevelSelected == 4)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(5*TEXT_HEIGHT3), color3, font3);
    else if (TextSelected == 4 && LevelSelected != 4)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(5*TEXT_HEIGHT3), color2, font3);
    ss.str("");
    ss << "Nivel 5"<< std::ends;
    if(TextSelected != 5 && LevelSelected != 5)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(6*TEXT_HEIGHT3), color, font3);
    else if((TextSelected == 5 && LevelSelected == 5) ||LevelSelected == 5)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(6*TEXT_HEIGHT3), color3, font3);
    else if (TextSelected == 5 && LevelSelected != 5)
        drawString(ss.str().c_str(),((screenWidth/2.0)-3.5), (screenHeight/2)-(6*TEXT_HEIGHT3), color2, font3);
    ss.str("");

    ss << "Salir"<< std::ends;
    if(TextSelected != 6 )
        drawString(ss.str().c_str(),((screenWidth/2.0)+6), (screenHeight/2)-(8*TEXT_HEIGHT3), color, font3);
    else if(TextSelected == 6)
        drawString(ss.str().c_str(),((screenWidth/2.0)+6), (screenHeight/2)-(8*TEXT_HEIGHT3), color2, font3);
    ss.str("");

    ss << "Mejor Nivel 1: "<< scoreLevel1 <<std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT, color, font);
    ss.str(""); // clear buffer

    ss << "Mejor Nivel 2: "<< scoreLevel2 <<std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT*2, color, font);
    ss.str(""); // clear buffer

    ss << "Mejor Nivel 3: "<< scoreLevel3 <<std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT*3, color, font);
    ss.str(""); // clear buffer

    ss << "Mejor Nivel 4: "<< scoreLevel4 <<std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT*4, color, font);
    ss.str(""); // clear buffer

    ss << "Mejor Nivel 5: "<< scoreLevel5 <<std::ends;  // add 0(ends) at the end
    drawString(ss.str().c_str(), 1, screenHeight-TEXT_HEIGHT*5, color, font);
    ss.str(""); // clear buffer


    // restore projection matrix
    glPopMatrix();                   // restore to previous projection matrix

    // restore modelview matrix
    glMatrixMode(GL_MODELVIEW);      // switch to modelview matrix
    glPopMatrix();                   // restore to previous modelview matrix
}


///////////////////////////////////////////////////////////////////////////////
// set projection matrix as orthogonal
///////////////////////////////////////////////////////////////////////////////
void toOrtho()
{
    // set viewport to be the entire window
    glViewport(0, 0, (GLsizei)screenWidth, (GLsizei)screenHeight);

    // set orthographic viewing frustum
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, screenWidth, 0, screenHeight, -1, 1);

    // switch to modelview matrix in order to set scene
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}



///////////////////////////////////////////////////////////////////////////////
// set the projection matrix as perspective
///////////////////////////////////////////////////////////////////////////////
void toPerspective()
{
    // set viewport to be the entire window
    glViewport(0, 0, (GLsizei)screenWidth, (GLsizei)screenHeight);

    // set perspective viewing frustum
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0f, (float)(screenWidth)/screenHeight, 0.0001f, 100.0f); // FOV, AspectRatio, NearClip, FarClip

    // switch to modelview matrix in order to set scene
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}



///////////////////////////////////////////////////////////////////////////////
// Read/Write Scores
///////////////////////////////////////////////////////////////////////////////

void loadScores()
{
    std::ifstream in( "Levels/Scores.txt");
  if( !in )
  {
    in.close( );
    throw std::runtime_error(
      std::string( "Error: Could not open \"" ) + "Levels/Scores.txt" + "\""
      );
  } // end if
  std::istringstream buffer(
    std::string(
      ( std::istreambuf_iterator< char >( in ) ),
      std::istreambuf_iterator< char >( )
      )
    );
  in.close( );
  buffer >> scoreLevel1 >> scoreLevel2 >> scoreLevel3 >> scoreLevel4 >> scoreLevel5;
}

void writeScores(double score)
{
    switch (LevelSelected)
    {
    case 1:
        if(scoreLevel1 < score)
        {
            scoreLevel1 = score;
        }
        break;
    case 2:
        if(scoreLevel2 < score)
        {
            scoreLevel2 = score;
        }
        break;
    case 3:
        if(scoreLevel3 < score)
        {
            scoreLevel3 = score;
        }
        break;
    case 4:
        if(scoreLevel4 < score)
        {
            scoreLevel4 = score;
        }
        break;
    case 5:
        if(scoreLevel5 < score)
        {
            scoreLevel5 = score;
        }
        break;
    }
      std::ofstream myfile;
      myfile.open ("Levels/Scores.txt");
      myfile << scoreLevel1;
      myfile << " ";
      myfile << scoreLevel2;
      myfile << " ";
      myfile << scoreLevel3;
      myfile << " ";
      myfile << scoreLevel4;
      myfile << " ";
      myfile << scoreLevel5;
      myfile.close();
}

void exitCB()
{
    if(myWorld != nullptr)
        delete (myWorld);
    if(myMenu != nullptr)
        delete (myMenu);
    exit(0);
}
