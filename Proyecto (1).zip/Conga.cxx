#include "Conga.h"
// -------------------------------------------------------------------------
Conga::
Conga( const std::string& obj_fname )
{
    this->m_MonkeyBodyMesh = new Mesh(obj_fname,0.729411,0.474509,0.184313);
}

Conga::
~Conga()
{
    if(this->m_MonkeyBodyMesh != nullptr)
        delete(this->m_MonkeyBodyMesh);
    this->m_MonkeyBodyMesh = nullptr;
    for(Monkey* c : this->m_Conga)
        delete (c);
}
int Conga::
getSizeofConga()
{
    return this->m_Conga.size();
}

void Conga::
changeVboSup()
{
    this->m_MonkeyBodyMesh->changeVboSup();
}
Monkey* Conga::
getHead()
{
    return this->m_Conga[0];
}

void Conga::
addMonkey(int xAnt, int zAnt)
{
    if(this->m_Conga.empty())
    {
        this->m_Conga.push_back(new Monkey("Param/mono_body.txt",&this->m_MonkeyBodyMesh));
    }
    else
    {
        Monkey* oldTail = this->m_Conga[this->m_Conga.size()-1];
        this->m_Conga.push_back(new Monkey("Param/mono_body.txt",&this->m_MonkeyBodyMesh));
        this->m_Conga[this->m_Conga.size()-1]->setCoordX(xAnt);
        this->m_Conga[this->m_Conga.size()-1]->setCoordY(oldTail->getCoordY());
        this->m_Conga[this->m_Conga.size()-1]->setCoordZ(zAnt);
        this->m_Conga[this->m_Conga.size()-1]->setQuaternionAxis(this->m_Conga[this->m_Conga.size()-2]->getQuaternionAxis());
        this->m_Conga[this->m_Conga.size()-1]->setQuaternionReal(this->m_Conga[this->m_Conga.size()-2]->getQuaternionReal());
    }
}

std::vector<Monkey*> Conga::
getMonkeys()
{
    return this->m_Conga;
}

void Conga::
teleportMonkeys(int i, int j)
{
    if(i == 30 || i == -30)
    {
        this->m_Conga[0]->setCoordX(i*-1);
    }
    else if(j == 30 || j == -30)
    {
        this->m_Conga[0]->setCoordZ(j*-1);
    }
}

void Conga::
moveMonkeys(int direction, int jump)
{
    bool animando = false;
    if(this->m_ActualDirection == 1 && direction == 2 )
        direction = 1;
    else if(this->m_ActualDirection == 2 && direction == 1 )
        direction = 2;
    else if(this->m_ActualDirection == 3 && direction == 4 )
        direction = 3;
    else if(this->m_ActualDirection == 4 && direction == 3 )
        direction = 4;
    if(jump == 1 || jump == 2)
        direction = this->m_ActualDirection;
    if(!animando)
    {
        if(this->m_Conga.size() > 1 )
        {
            for(unsigned int i = this->m_Conga.size()-1;i > 0; i--)
            {
                this->m_Conga[i]->setCoordX(this->m_Conga[i-1]->getCoordX());
                this->m_Conga[i]->setCoordY(this->m_Conga[i-1]->getCoordY());
                this->m_Conga[i]->setCoordZ(this->m_Conga[i-1]->getCoordZ());
                if(this->m_Conga[i]->getDirection() != this->m_Conga[i-1]->getDirection())
                {
                    this->m_Conga[i]->setTimes();
                    this->m_Conga[i]->setPrevCoordX(this->m_Conga[i]->getCoordX());
                    this->m_Conga[i]->setPrevCoordY(this->m_Conga[i]->getCoordY());
                    this->m_Conga[i]->setPrevCoordZ(this->m_Conga[i]->getCoordZ());
                    this->m_Conga[i]->setNextDirection(this->m_Conga[i-1]->getDirection());
                }
                else
                {
                    this->m_Conga[i]->setQuaternionAxis(this->m_Conga[i-1]->getQuaternionAxis());
                    this->m_Conga[i]->setQuaternionReal(this->m_Conga[i-1]->getQuaternionReal());
                }
            }
        }
        switch(direction)
        {
            case 1:
                if (this->m_ActualDirection != 2 && this->m_ActualDirection != 1)
                {
                    this->m_Conga[0]->setTimes();
                    this->m_Conga[0]->setPrevCoordX(this->m_Conga[0]->getCoordX());
                    this->m_Conga[0]->setPrevCoordY(this->m_Conga[0]->getCoordY());
                    this->m_Conga[0]->setPrevCoordZ(this->m_Conga[0]->getCoordZ());
                    this->m_Conga[0]->setNextDirection(1);
                    this->m_Conga[0]->increaseCoordX();
                    this->m_ActualDirection = 1;
                }
                else if(this->m_ActualDirection == 1)
                {
                    this->m_Conga[0]->setNextDirection(1);
                    this->m_Conga[0]->increaseCoordX();
                    this->m_ActualDirection = 1;
                }
                break;
            case 2:
                if (this->m_ActualDirection != 1 && this->m_ActualDirection != 2)
                {
                    this->m_Conga[0]->setTimes();
                    this->m_Conga[0]->setPrevCoordX(this->m_Conga[0]->getCoordX());
                    this->m_Conga[0]->setPrevCoordY(this->m_Conga[0]->getCoordY());
                    this->m_Conga[0]->setPrevCoordZ(this->m_Conga[0]->getCoordZ());
                    this->m_Conga[0]->setNextDirection(2);
                    this->m_ActualDirection = 2;
                    this->m_Conga[0]->decreaseCoordX();
                }
                else if(this->m_ActualDirection == 2)
                {
                    this->m_Conga[0]->setNextDirection(2);
                    this->m_ActualDirection = 2;
                    this->m_Conga[0]->decreaseCoordX();
                }
                break;
            case 3:
                if (this->m_ActualDirection != 4&& this->m_ActualDirection != 3)
                {
                    this->m_Conga[0]->setTimes();
                    this->m_Conga[0]->setPrevCoordX(this->m_Conga[0]->getCoordX());
                    this->m_Conga[0]->setPrevCoordY(this->m_Conga[0]->getCoordY());
                    this->m_Conga[0]->setPrevCoordZ(this->m_Conga[0]->getCoordZ());
                    this->m_Conga[0]->setNextDirection(3);
                    this->m_ActualDirection = 3;
                    this->m_Conga[0]->increaseCoordZ();
                }
                else if(this->m_ActualDirection == 3)
                {
                    this->m_Conga[0]->setNextDirection(3);
                    this->m_ActualDirection = 3;
                    this->m_Conga[0]->increaseCoordZ();
                }
                break;
            case 4:
                if (this->m_ActualDirection != 3 && this->m_ActualDirection != 4)
                {
                    this->m_Conga[0]->setTimes();
                    this->m_Conga[0]->setPrevCoordX(this->m_Conga[0]->getCoordX());
                    this->m_Conga[0]->setPrevCoordY(this->m_Conga[0]->getCoordY());
                    this->m_Conga[0]->setPrevCoordZ(this->m_Conga[0]->getCoordZ());
                    this->m_Conga[0]->setNextDirection(4);
                    this->m_ActualDirection = 4;
                    this->m_Conga[0]->decreaseCoordZ();
                }
                else if(this->m_ActualDirection == 4)
                {
                    this->m_Conga[0]->setNextDirection(4);
                    this->m_ActualDirection = 4;
                    this->m_Conga[0]->decreaseCoordZ();
                }
                break;
        }
        if(jump == 1)
        {
            this->m_Conga[0]->increaseCoordY();
        }
        else if (jump == 2)
        {
            this->m_Conga[0]->decreaseCoordY();
        }
    }

}


void Conga::
drawInOpenGLContext( GLenum mode, bool fpc )
{

    for(unsigned int i = 0 ; i < this->m_Conga.size(); i++)
    {
        if(i == 0 && fpc)
            this->m_Conga[i]->drawInOpenGLContext(mode,true);
        else
            this->m_Conga[i]->drawInOpenGLContext(mode,false);
    }
}
