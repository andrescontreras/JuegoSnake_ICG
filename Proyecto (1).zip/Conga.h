
// -------------------------------------------------------------------------
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// -------------------------------------------------------------------------
#ifndef __Conga__h__
#define __Conga__h__

#include "Monkey.h"
#include <GL/glut.h>
#include <vector>
#include <string>

class Conga
{
public:
    Conga(const std::string& obj_fname);
    virtual ~Conga();

    void                    addMonkey(int xAnt, int zAnt);
    Monkey*                 getHead();
    std::vector<Monkey*>    getMonkeys();
    int                     getSizeofConga();
    void                    teleportMonkeys(int i, int j);
    void                    changeVboSup();

    void moveMonkeys(int direction, int jump);

    virtual void drawInOpenGLContext( GLenum mode , bool fpc);
protected:
    std::vector<Monkey*>     m_Conga;
    int                      m_ActualDirection;
    Mesh*                    m_MonkeyBodyMesh;
};
#endif // __Conga__h__

// eof - Conga.h

