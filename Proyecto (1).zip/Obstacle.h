#ifndef __Obstacle__h__
#define __Obstacle__h__

#include "Object.h"
#include <GL/glut.h>
#include <vector>
#include <utility>
#include <tuple>
#include <stdlib.h>     /* srand, rand */
#include <time.h>

class Obstacle
{
public:
    //! Streaming methods
  //@{
  friend std::istream& operator>>( std::istream& i, Obstacle& s )
    {
      s._strIn( i );
      return( i );
    }

  friend std::istream& operator>>( std::istream& i, Obstacle* s )
    {
      s->_strIn( i );
      return( i );
    }

  friend std::ostream& operator<<( std::ostream& o, const Obstacle& s )
    {
      s._strOut( o );
      return( o );
    }

  friend std::ostream& operator<<( std::ostream& o, const Obstacle* s )
    {
      s->_strOut( o );
      return( o );
    }
  //@}
    Obstacle(const std::string& obj_fname, const std::string& obj_fname2, const std::string& obs_fname );
    virtual ~Obstacle();

    std::vector<Object*>  getObstacles();
    void changeVboSup();
    std::vector<std::tuple<int,int,int>> getObstaclesCoordinates();
    std::vector<std::tuple<int,int,int>> getExternalObstaclesCoordinates();
    void                  addObstacle(int i, int j);
    void                  addExternalObstacle(int i, int j);
    virtual void drawInOpenGLContext(GLenum mode);
protected:

  //! Here's where the real streaming is done
  //@{
  void _strIn( std::istream& in );
  void _strOut( std::ostream& out ) const;
  //@}


protected:
    Mesh*                  m_InternalObstacleMesh;
    Mesh*                  m_ExternalObstacleMesh;
    std::vector<Object*>   m_Obstacles;
    std::vector<Object*>   m_ExternalObstacles;
};

#endif // __Obstacle__h__

// eof - Obstacle.h
